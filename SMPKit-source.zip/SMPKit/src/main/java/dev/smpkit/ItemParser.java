package dev.smpkit;

import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Locale;

/** Parses "MATERIAL:AMOUNT:enchant=level;enchant=level:<MiniMessage name>". Only the material is required. */
public final class ItemParser {

    private ItemParser() { }

    public static ItemStack parse(SMPKit plugin, String line, String context) {
        String[] parts = line.split(":", 4);
        Material material = Material.matchMaterial(parts[0].trim());
        if (material == null || !material.isItem()) {
            plugin.getLogger().warning(context + ": unknown item '" + parts[0] + "'");
            return null;
        }
        int amount = 1;
        if (parts.length > 1 && !parts[1].isBlank()) {
            try {
                amount = Integer.parseInt(parts[1].trim());
            } catch (NumberFormatException ex) {
                plugin.getLogger().warning(context + ": bad amount in '" + line + "'");
            }
        }
        ItemStack stack = new ItemStack(material, Math.max(1, Math.min(amount, material.getMaxStackSize())));

        if (parts.length > 2 && !parts[2].isBlank()) {
            for (String entry : parts[2].split(";")) {
                String[] kv = entry.split("=");
                Enchantment enchantment = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(kv[0].trim().toLowerCase(Locale.ROOT)));
                if (enchantment == null) {
                    plugin.getLogger().warning(context + ": unknown enchantment '" + kv[0] + "'");
                    continue;
                }
                int level = 1;
                if (kv.length > 1) {
                    try {
                        level = Integer.parseInt(kv[1].trim());
                    } catch (NumberFormatException ignored) { }
                }
                ItemMeta meta = stack.getItemMeta();
                if (meta instanceof EnchantmentStorageMeta storage) {
                    storage.addStoredEnchant(enchantment, level, true);
                    stack.setItemMeta(storage);
                } else {
                    stack.addUnsafeEnchantment(enchantment, level);
                }
            }
        }
        if (parts.length > 3 && !parts[3].isBlank()) {
            ItemMeta meta = stack.getItemMeta();
            meta.displayName(MiniMessage.miniMessage().deserialize(parts[3]).decoration(TextDecoration.ITALIC, false));
            stack.setItemMeta(meta);
        }
        return stack;
    }
}
