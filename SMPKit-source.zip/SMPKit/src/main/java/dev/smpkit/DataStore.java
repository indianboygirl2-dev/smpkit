package dev.smpkit;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Set;
import java.util.logging.Level;

/** Tiny persistent store (data.yml): craft counters, homes, altars, death bans... */
public final class DataStore {

    private final SMPKit plugin;
    private final File file;
    private final YamlConfiguration yaml;

    public DataStore(SMPKit plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
        this.yaml = YamlConfiguration.loadConfiguration(file);
    }

    public int getInt(String path) { return yaml.getInt(path, 0); }
    public long getLong(String path, long def) { return yaml.getLong(path, def); }
    public boolean getBoolean(String path) { return yaml.getBoolean(path, false); }
    public boolean contains(String path) { return yaml.contains(path); }
    public String getString(String path) { return yaml.getString(path); }
    public Location getLocation(String path) { return yaml.getLocation(path); }

    public Set<String> keys(String path) {
        ConfigurationSection section = yaml.getConfigurationSection(path);
        return section == null ? Set.of() : section.getKeys(false);
    }

    /** Pass null to remove the value. */
    public void set(String path, Object value) {
        yaml.set(path, value);
        save();
    }

    public void save() {
        try {
            plugin.getDataFolder().mkdirs();
            yaml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Could not save data.yml", ex);
        }
    }
}
