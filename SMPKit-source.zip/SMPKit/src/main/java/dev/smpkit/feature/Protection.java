package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import dev.smpkit.Util;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Player protection features. */
public final class Protection {

    private Protection() { }

    // ------------------------------------------------------------------------------------------

    public static final class Naked extends SimpleFeature {
        public Naked(SMPKit plugin) {
            super(plugin, "naked-protection", Material.LEATHER_CHESTPLATE, "Naked Protection",
                    "Players wearing no armor can't be hurt by other players.");
        }

        @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
        public void onHit(EntityDamageEvent event) {
            if (!(event.getEntity() instanceof Player victim)) return;
            Player attacker = Util.attacker(event);
            if (attacker == null || attacker.equals(victim)) return;
            if (!Util.hasArmor(victim)) {
                event.setCancelled(true);
                plugin.messages().send(attacker, "naked-protected");
            }
        }
    }

    // ------------------------------------------------------------------------------------------

    public static final class Afk extends SimpleFeature {
        private final Map<UUID, Long> lastActive = new HashMap<>();
        private long afkMillis;
        private boolean allDamage;

        public Afk(SMPKit plugin) {
            super(plugin, "afk-protection", Material.CLOCK, "AFK Protection",
                    "AFK players can't be hurt by other players.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            afkMillis = config.getLong("afk-seconds", 300) * 1000L;
            allDamage = config.getBoolean("all-damage", false);
        }

        @Override
        protected void onStop() {
            lastActive.clear();
        }

        private boolean isAfk(Player player) {
            Long last = lastActive.get(player.getUniqueId());
            if (last == null) {
                lastActive.put(player.getUniqueId(), System.currentTimeMillis());
                return false;
            }
            return System.currentTimeMillis() - last >= afkMillis;
        }

        @EventHandler
        public void onMove(PlayerMoveEvent event) {
            if (event.hasChangedPosition()) lastActive.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
        }

        @EventHandler
        public void onInteract(PlayerInteractEvent event) {
            lastActive.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
        }

        @EventHandler
        public void onJoin(PlayerJoinEvent event) {
            lastActive.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent event) {
            lastActive.remove(event.getPlayer().getUniqueId());
        }

        @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
        public void onDamage(EntityDamageEvent event) {
            if (!(event.getEntity() instanceof Player victim) || !isAfk(victim)) return;
            if (allDamage || Util.attacker(event) != null) event.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------------------------------

    /** Falling into the void teleports you back to the last safe spot instead of killing you. */
    public static final class VoidSave extends SimpleFeature {
        private final Map<UUID, Location> safe = new HashMap<>();
        private BukkitTask task;
        private double damage;

        public VoidSave(SMPKit plugin) {
            super(plugin, "void-protection", Material.ENDER_EYE, "Void Protection",
                    "Teleports you to safe ground when you fall into the void.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            damage = config.getDouble("damage", 2.0);
        }

        @Override
        protected void onStart() {
            task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
                for (Player player : plugin.getServer().getOnlinePlayers()) {
                    if (player.isFlying() || !player.isOnGround()) continue;
                    Block below = player.getLocation().subtract(0, 1, 0).getBlock();
                    if (below.getType().isSolid()) safe.put(player.getUniqueId(), player.getLocation());
                }
            }, 20L, 20L);
        }

        @Override
        protected void onStop() {
            if (task != null) task.cancel();
            safe.clear();
        }

        @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
        public void onDamage(EntityDamageEvent event) {
            if (event.getCause() != EntityDamageEvent.DamageCause.VOID || !(event.getEntity() instanceof Player player)) return;
            Location destination = safe.get(player.getUniqueId());
            if (destination == null || destination.getWorld() != player.getWorld()) {
                destination = player.getWorld().getSpawnLocation();
            }
            event.setCancelled(true);
            player.setFallDistance(0);
            player.setVelocity(new Vector(0, 0, 0));
            player.teleport(destination);
            if (damage > 0) plugin.getServer().getScheduler().runTask(plugin, () -> player.damage(damage));
        }
    }

    // ------------------------------------------------------------------------------------------

    /** Removes a player's thrown ender pearls when they log out (breaks pearl stasis chambers). */
    public static final class AntiStasis extends SimpleFeature {
        public AntiStasis(SMPKit plugin) {
            super(plugin, "anti-stasis", Material.ENDER_PEARL, "Anti Stasis",
                    "Removes a player's ender pearls when they log out.");
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent event) {
            UUID id = event.getPlayer().getUniqueId();
            for (World world : plugin.getServer().getWorlds()) {
                for (EnderPearl pearl : world.getEntitiesByClass(EnderPearl.class)) {
                    if (pearl.getShooter() instanceof Player shooter && shooter.getUniqueId().equals(id)) pearl.remove();
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------

    /** /pvp toggles whether you can fight other players. */
    public static final class PvpToggle extends SimpleFeature {
        private boolean defaultEnabled;

        public PvpToggle(SMPKit plugin) {
            super(plugin, "pvp-toggle", Material.IRON_SWORD, "PvP Toggle",
                    "Players can switch PvP on or off with /pvp.");
        }

        @Override
        public List<String> commands() { return List.of("pvp"); }

        @Override
        protected void load(ConfigurationSection config) {
            defaultEnabled = config.getBoolean("default-enabled", true);
        }

        private boolean pvpOn(Player player) {
            String path = "pvp." + player.getUniqueId();
            return plugin.data().contains(path) ? plugin.data().getBoolean(path) : defaultEnabled;
        }

        @Override
        public boolean handleCommand(CommandSender sender, String command, String[] args) {
            Player player = playerOnly(sender);
            if (player == null) return true;
            boolean now;
            if (args.length > 0 && args[0].equalsIgnoreCase("on")) now = true;
            else if (args.length > 0 && args[0].equalsIgnoreCase("off")) now = false;
            else now = !pvpOn(player);
            plugin.data().set("pvp." + player.getUniqueId(), now);
            plugin.messages().send(player, now ? "pvp-on" : "pvp-off");
            return true;
        }

        @Override
        public List<String> tabComplete(CommandSender sender, String command, String[] args) {
            return args.length == 1 ? filter(List.of("on", "off"), args[0]) : List.of();
        }

        @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
        public void onDamage(EntityDamageEvent event) {
            if (!(event.getEntity() instanceof Player victim)) return;
            Player attacker = Util.attacker(event);
            if (attacker == null || attacker.equals(victim)) return;
            if (!pvpOn(attacker)) {
                event.setCancelled(true);
                plugin.messages().send(attacker, "pvp-disabled-self");
            } else if (!pvpOn(victim)) {
                event.setCancelled(true);
                plugin.messages().send(attacker, "pvp-disabled-other");
            }
        }
    }

    // ------------------------------------------------------------------------------------------

    /** Scales all player-vs-player damage by a percentage. */
    public static final class DamageMod extends SimpleFeature {
        private double percent = 100;

        public DamageMod(SMPKit plugin) {
            super(plugin, "damage-mod", Material.POTION, "Damage Modification",
                    "Increase or decrease all PvP damage by a percentage.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            percent = config.getDouble("percent", 100.0);
        }

        @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
        public void onDamage(EntityDamageEvent event) {
            if (!(event.getEntity() instanceof Player victim)) return;
            Player attacker = Util.attacker(event);
            if (attacker == null || attacker.equals(victim)) return;
            event.setDamage(event.getDamage() * percent / 100.0);
        }
    }
}
