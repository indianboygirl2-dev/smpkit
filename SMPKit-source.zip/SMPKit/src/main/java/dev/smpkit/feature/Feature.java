package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;

import java.util.Collection;
import java.util.List;
import java.util.Locale;

/**
 * One toggleable module. Listeners are only registered while the feature is enabled.
 * State kept in fields survives /smpkit reload (e.g. who is vanished).
 */
public abstract class Feature implements Listener {

    protected final SMPKit plugin;
    private boolean running;

    protected Feature(SMPKit plugin) {
        this.plugin = plugin;
    }

    /** Key under "features:" in config.yml. */
    public abstract String key();

    // --- metadata for the settings GUI
    public Material icon() { return Material.PAPER; }
    public String title() { return key(); }
    public String description() { return ""; }

    public List<String> commands() { return List.of(); }

    public boolean handleCommand(CommandSender sender, String command, String[] args) { return false; }

    public List<String> tabComplete(CommandSender sender, String command, String[] args) { return List.of(); }

    /** Read config values. Called on start and on every reload while enabled. */
    protected void load(ConfigurationSection config) { }

    /** Called once when the feature switches on (after load). */
    protected void onStart() { }

    /** Called once when the feature switches off or the plugin disables. */
    protected void onStop() { }

    public final boolean isRunning() { return running; }

    public final void apply(ConfigurationSection section) {
        boolean enabled = section != null && section.getBoolean("enabled", true);
        if (enabled && !running) {
            load(section);
            onStart();
            plugin.getServer().getPluginManager().registerEvents(this, plugin);
            running = true;
        } else if (enabled) {
            load(section);
        } else if (running) {
            shutdown();
        }
    }

    public final void shutdown() {
        if (!running) return;
        HandlerList.unregisterAll(this);
        onStop();
        running = false;
    }

    // ---------------------------------------------------------------- helpers

    /** Returns the sender as a player, or tells them it's players-only and returns null. */
    protected Player playerOnly(CommandSender sender) {
        if (sender instanceof Player player) return player;
        plugin.messages().send(sender, "players-only");
        return null;
    }

    protected static TagResolver ph(String key, Object value) {
        return Placeholder.unparsed(key, String.valueOf(value));
    }

    public static List<String> filter(Collection<String> options, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        return options.stream()
                .filter(o -> o.toLowerCase(Locale.ROOT).startsWith(lower))
                .sorted()
                .toList();
    }

    protected static List<String> onlinePlayers(String prefix) {
        return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), prefix);
    }
}
