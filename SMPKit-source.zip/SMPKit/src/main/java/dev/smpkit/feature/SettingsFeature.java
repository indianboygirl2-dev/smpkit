package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * /settings opens a paged GUI where every feature is an icon you can click to switch on or off.
 * /settings <keyword> searches. Players with smpkit.settings.view can look but not change anything.
 */
public final class SettingsFeature extends Feature {

    private static final int PER_PAGE = 28;
    private static final int PREVIOUS = 48, INFO = 49, NEXT = 50, CLOSE = 53;

    private final NamespacedKey featureKey;

    /** Marks our inventories and remembers what they show. */
    private static final class Holder implements InventoryHolder {
        private Inventory inventory;
        private List<Feature> shown = new ArrayList<>();
        private String search = "";
        private int page;

        @Override
        public Inventory getInventory() { return inventory; }
    }

    public SettingsFeature(SMPKit plugin) {
        super(plugin);
        this.featureKey = new NamespacedKey(plugin, "feature");
    }

    @Override public String key() { return "settings"; }
    @Override public Material icon() { return Material.COMPARATOR; }
    @Override public String title() { return "Settings"; }
    @Override public String description() { return "The settings menu itself."; }
    @Override public List<String> commands() { return List.of("settings"); }

    @Override
    public boolean handleCommand(CommandSender sender, String command, String[] args) {
        Player player = playerOnly(sender);
        if (player == null) return true;
        open(player, String.join(" ", args), 0);
        return true;
    }

    // ------------------------------------------------------------------------------------------ building

    private void open(Player player, String search, int page) {
        Holder holder = new Holder();
        holder.search = search;
        holder.page = page;
        holder.inventory = plugin.getServer().createInventory(holder, 54, Component.text("SMPKit Settings"));
        render(holder);
        player.openInventory(holder.inventory);
    }

    private void render(Holder holder) {
        String needle = holder.search.toLowerCase(Locale.ROOT).trim();
        List<Feature> list = new ArrayList<>();
        for (Feature feature : plugin.features()) {
            if (feature == this) continue;
            if (needle.isEmpty() || feature.title().toLowerCase(Locale.ROOT).contains(needle)
                    || feature.key().contains(needle) || feature.description().toLowerCase(Locale.ROOT).contains(needle)) {
                list.add(feature);
            }
        }
        int pages = Math.max(1, (int) Math.ceil(list.size() / (double) PER_PAGE));
        holder.page = Math.max(0, Math.min(holder.page, pages - 1));
        holder.shown = list;

        Inventory inv = holder.inventory;
        inv.clear();
        ItemStack filler = named(Material.BLUE_STAINED_GLASS_PANE, Component.text(" "));
        for (int slot = 0; slot < 54; slot++) inv.setItem(slot, filler);

        int start = holder.page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < list.size(); i++) {
            int slot = (i / 7 + 1) * 9 + (i % 7) + 1;
            inv.setItem(slot, featureItem(list.get(start + i)));
        }

        if (holder.page > 0) inv.setItem(PREVIOUS, named(Material.ARROW, line("Previous page", NamedTextColor.YELLOW)));
        if (holder.page < pages - 1) inv.setItem(NEXT, named(Material.ARROW, line("Next page", NamedTextColor.YELLOW)));
        String info = "Page " + (holder.page + 1) + "/" + pages + (needle.isEmpty() ? "" : "  (search: " + needle + ")");
        inv.setItem(INFO, named(Material.BOOK, line(info, NamedTextColor.AQUA)));
        inv.setItem(CLOSE, named(Material.BARRIER, line("Close", NamedTextColor.RED)));
    }

    private ItemStack featureItem(Feature feature) {
        boolean on = feature.isRunning();
        ItemStack item = new ItemStack(feature.icon());
        ItemMeta meta = item.getItemMeta();
        meta.displayName(line(feature.title(), on ? NamedTextColor.GREEN : NamedTextColor.RED));

        List<Component> lore = new ArrayList<>();
        for (String chunk : wrap(feature.description(), 38)) lore.add(line(chunk, NamedTextColor.GRAY));
        lore.add(Component.empty());
        lore.add(line(on ? "\u25a0 ENABLED" : "\u25a0 DISABLED", on ? NamedTextColor.GREEN : NamedTextColor.RED));
        lore.add(line("Click to toggle", NamedTextColor.DARK_GRAY));
        meta.lore(lore);

        meta.setEnchantmentGlintOverride(on);
        meta.addItemFlags(ItemFlag.values());
        meta.getPersistentDataContainer().set(featureKey, PersistentDataType.STRING, feature.key());
        item.setItemMeta(meta);
        return item;
    }

    private static ItemStack named(Material material, Component name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(name);
        meta.addItemFlags(ItemFlag.values());
        item.setItemMeta(meta);
        return item;
    }

    private static Component line(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private static List<String> wrap(String text, int width) {
        List<String> lines = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        for (String word : text.split(" ")) {
            if (current.length() + word.length() + 1 > width && current.length() > 0) {
                lines.add(current.toString());
                current.setLength(0);
            }
            if (current.length() > 0) current.append(' ');
            current.append(word);
        }
        if (current.length() > 0) lines.add(current.toString());
        return lines;
    }

    // ------------------------------------------------------------------------------------------ clicks

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof Holder holder)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!event.getView().getTopInventory().equals(event.getClickedInventory())) return;

        int slot = event.getSlot();
        if (slot == CLOSE) {
            player.closeInventory();
            return;
        }
        if (slot == PREVIOUS || slot == NEXT) {
            if (event.getCurrentItem() == null || event.getCurrentItem().getType() != Material.ARROW) return;
            holder.page += slot == NEXT ? 1 : -1;
            render(holder);
            return;
        }

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        String key = clicked.getItemMeta().getPersistentDataContainer().get(featureKey, PersistentDataType.STRING);
        if (key == null) return;

        if (!player.hasPermission("smpkit.settings")) {
            plugin.messages().send(player, "settings-readonly");
            return;
        }
        plugin.toggleFeature(key);
        render(holder);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof Holder) event.setCancelled(true);
    }
}
