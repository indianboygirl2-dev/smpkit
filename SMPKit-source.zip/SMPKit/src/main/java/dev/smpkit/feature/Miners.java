package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;

/** Tree miner and vein miner. */
public final class Miners {

    private Miners() { }

    private abstract static class AbstractMiner extends SimpleFeature {
        private final Set<UUID> working = new HashSet<>();
        private boolean requireSneak;
        private int maxBlocks;

        protected AbstractMiner(SMPKit plugin, String key, Material icon, String title, String description) {
            super(plugin, key, icon, title, description);
        }

        protected abstract boolean validTool(Material tool);
        protected abstract boolean validBlock(Material block);
        /** Whether a neighbour belongs to the same group as the origin block. */
        protected abstract boolean sameGroup(Material origin, Material other);

        @Override
        protected void load(ConfigurationSection config) {
            requireSneak = config.getBoolean("require-sneak", true);
            maxBlocks = Math.max(1, config.getInt("max-blocks", 64));
        }

        @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
        public void onBreak(BlockBreakEvent event) {
            Player player = event.getPlayer();
            if (working.contains(player.getUniqueId())) return;
            if (player.getGameMode() != GameMode.SURVIVAL) return;
            if (requireSneak && !player.isSneaking()) return;

            ItemStack tool = player.getInventory().getItemInMainHand();
            Block origin = event.getBlock();
            if (!validTool(tool.getType()) || !validBlock(origin.getType())) return;

            Set<Block> found = search(origin);
            found.remove(origin);
            if (found.isEmpty()) return;

            working.add(player.getUniqueId());
            try {
                for (Block block : found) {
                    if (!damage(player, tool)) break;
                    BlockBreakEvent extra = new BlockBreakEvent(block, player);
                    Bukkit.getPluginManager().callEvent(extra); // lets protection plugins veto it
                    if (!extra.isCancelled()) block.breakNaturally(tool);
                }
            } finally {
                working.remove(player.getUniqueId());
            }
        }

        private Set<Block> search(Block origin) {
            Set<Block> result = new LinkedHashSet<>();
            Queue<Block> queue = new ArrayDeque<>();
            queue.add(origin);
            result.add(origin);
            while (!queue.isEmpty() && result.size() < maxBlocks) {
                Block current = queue.poll();
                for (int dx = -1; dx <= 1; dx++) {
                    for (int dy = -1; dy <= 1; dy++) {
                        for (int dz = -1; dz <= 1; dz++) {
                            if (dx == 0 && dy == 0 && dz == 0) continue;
                            Block next = current.getRelative(dx, dy, dz);
                            if (result.contains(next) || !sameGroup(origin.getType(), next.getType())) continue;
                            result.add(next);
                            queue.add(next);
                            if (result.size() >= maxBlocks) return result;
                        }
                    }
                }
            }
            return result;
        }

        /** Applies one point of durability. Returns false when the tool broke or can't be used. */
        private boolean damage(Player player, ItemStack tool) {
            if (!(tool.getItemMeta() instanceof Damageable meta)) return true;
            int max = tool.getType().getMaxDurability();
            if (max <= 0) return true;
            meta.setDamage(meta.getDamage() + 1);
            if (meta.getDamage() >= max) {
                player.getInventory().setItemInMainHand(null);
                return false;
            }
            tool.setItemMeta(meta);
            return true;
        }
    }

    public static final class TreeMiner extends AbstractMiner {
        public TreeMiner(SMPKit plugin) {
            super(plugin, "treeminer", Material.IRON_AXE, "Tree Miner",
                    "Sneak-chop a log with an axe to fell the whole tree.");
        }

        @Override protected boolean validTool(Material tool) { return Tag.ITEMS_AXES.isTagged(tool); }
        @Override protected boolean validBlock(Material block) { return Tag.LOGS.isTagged(block); }
        @Override protected boolean sameGroup(Material origin, Material other) { return Tag.LOGS.isTagged(other); }
    }

    public static final class VeinMiner extends AbstractMiner {
        public VeinMiner(SMPKit plugin) {
            super(plugin, "veinminer", Material.IRON_PICKAXE, "Vein Miner",
                    "Sneak-mine an ore with a pickaxe to mine the whole vein.");
        }

        private static boolean isOre(Material material) {
            return material.name().endsWith("_ORE") || material == Material.ANCIENT_DEBRIS;
        }

        private static String group(Material material) {
            return material.name().replaceFirst("^DEEPSLATE_", "");
        }

        @Override protected boolean validTool(Material tool) { return Tag.ITEMS_PICKAXES.isTagged(tool); }
        @Override protected boolean validBlock(Material block) { return isOre(block); }
        @Override protected boolean sameGroup(Material origin, Material other) {
            return isOre(other) && group(origin).equals(group(other));
        }
    }
}
