package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import org.bukkit.Material;

/** Feature with its metadata passed to the constructor. */
public abstract class SimpleFeature extends Feature {

    private final String key;
    private final Material icon;
    private final String title;
    private final String description;

    protected SimpleFeature(SMPKit plugin, String key, Material icon, String title, String description) {
        super(plugin);
        this.key = key;
        this.icon = icon;
        this.title = title;
        this.description = description;
    }

    @Override public final String key() { return key; }
    @Override public final Material icon() { return icon; }
    @Override public final String title() { return title; }
    @Override public final String description() { return description; }
}
