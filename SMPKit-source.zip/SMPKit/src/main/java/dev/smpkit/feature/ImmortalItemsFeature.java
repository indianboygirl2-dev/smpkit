package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRemoveEvent;
import org.bukkit.event.entity.ItemDespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.EnumSet;
import java.util.Locale;
import java.util.Set;

/** Dropped items that can't be destroyed by fire, lava, explosions, cactus, despawning or the void. */
public final class ImmortalItemsFeature extends Feature {

    private final Set<Material> immortal = EnumSet.noneOf(Material.class);
    private boolean preventDespawn;
    private boolean rescueFromVoid;

    public ImmortalItemsFeature(SMPKit plugin) {
        super(plugin);
    }

    @Override
    public String key() { return "immortal-items"; }

    @Override public org.bukkit.Material icon() { return org.bukkit.Material.NETHER_STAR; }
    @Override public String title() { return "Immortal Items"; }
    @Override public String description() { return "Listed items can never be destroyed on the ground."; }

    @Override
    protected void load(ConfigurationSection config) {
        preventDespawn = config.getBoolean("prevent-despawn", true);
        rescueFromVoid = config.getBoolean("rescue-from-void", true);
        immortal.clear();

        for (String entry : config.getStringList("materials")) {
            String name = entry.trim().toUpperCase(Locale.ROOT);
            if (name.endsWith("*")) {
                String prefix = name.substring(0, name.length() - 1);
                for (Material material : Material.values()) {
                    if (!material.isLegacy() && material.isItem() && material.name().startsWith(prefix)) {
                        immortal.add(material);
                    }
                }
            } else {
                Material material = Material.matchMaterial(name);
                if (material == null) {
                    plugin.getLogger().warning("immortal-items: unknown material '" + entry + "'");
                } else {
                    immortal.add(material);
                }
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Item item && immortal.contains(item.getItemStack().getType())) {
            // void is handled by the rescue below
            if (event.getCause() != EntityDamageEvent.DamageCause.VOID) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDespawn(ItemDespawnEvent event) {
        if (preventDespawn && immortal.contains(event.getEntity().getItemStack().getType())) {
            event.setCancelled(true);
        }
    }

    /** Items that fall out of the world are re-dropped at the main world's spawn. */
    @EventHandler
    public void onRemove(EntityRemoveEvent event) {
        if (!rescueFromVoid || !(event.getEntity() instanceof Item item)) return;

        EntityRemoveEvent.Cause cause = event.getCause();
        if (cause != EntityRemoveEvent.Cause.OUT_OF_WORLD && cause != EntityRemoveEvent.Cause.DEATH) return;

        World world = item.getWorld();
        if (item.getLocation().getY() >= world.getMinHeight()) return;

        ItemStack stack = item.getItemStack().clone();
        if (!immortal.contains(stack.getType())) return;

        Location spawn = plugin.getServer().getWorlds().get(0).getSpawnLocation().add(0.5, 1.0, 0.5);
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            Item rescued = spawn.getWorld().dropItem(spawn, stack);
            rescued.setVelocity(new Vector(0, 0, 0));
        });
    }
}
