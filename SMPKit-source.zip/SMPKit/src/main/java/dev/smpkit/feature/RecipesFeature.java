package dev.smpkit.feature;

import dev.smpkit.ItemParser;
import dev.smpkit.SMPKit;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.FurnaceRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;

import java.util.ArrayList;
import java.util.List;

/** Custom shaped / shapeless / furnace recipes and a vanilla recipe remover. */
public final class RecipesFeature extends Feature {

    private final List<NamespacedKey> registered = new ArrayList<>();

    public RecipesFeature(SMPKit plugin) {
        super(plugin);
    }

    @Override public String key() { return "custom-recipes"; }
    @Override public Material icon() { return Material.CRAFTING_TABLE; }
    @Override public String title() { return "Custom Recipes"; }
    @Override public String description() { return "Config-defined crafting and smelting recipes, plus a vanilla recipe remover."; }

    @Override
    protected void load(ConfigurationSection config) {
        unregister();

        for (String name : config.getStringList("remove-vanilla")) {
            NamespacedKey key = NamespacedKey.fromString(name);
            if (key == null || !Bukkit.removeRecipe(key)) plugin.getLogger().warning("custom-recipes: could not remove '" + name + "'");
        }

        ConfigurationSection shaped = config.getConfigurationSection("shaped");
        if (shaped != null) {
            for (String id : shaped.getKeys(false)) {
                try {
                    ItemStack result = ItemParser.parse(plugin, shaped.getString(id + ".result", ""), "recipe " + id);
                    ConfigurationSection ingredients = shaped.getConfigurationSection(id + ".ingredients");
                    List<String> shape = shaped.getStringList(id + ".shape");
                    if (result == null || ingredients == null || shape.isEmpty()) continue;
                    NamespacedKey key = new NamespacedKey(plugin, "shaped_" + id.toLowerCase());
                    ShapedRecipe recipe = new ShapedRecipe(key, result);
                    recipe.shape(shape.toArray(String[]::new));
                    for (String symbol : ingredients.getKeys(false)) {
                        Material material = Material.matchMaterial(ingredients.getString(symbol, ""));
                        if (material != null) recipe.setIngredient(symbol.charAt(0), material);
                    }
                    register(key, recipe);
                } catch (IllegalArgumentException ex) {
                    plugin.getLogger().warning("custom-recipes: bad shaped recipe '" + id + "': " + ex.getMessage());
                }
            }
        }

        ConfigurationSection shapeless = config.getConfigurationSection("shapeless");
        if (shapeless != null) {
            for (String id : shapeless.getKeys(false)) {
                try {
                    ItemStack result = ItemParser.parse(plugin, shapeless.getString(id + ".result", ""), "recipe " + id);
                    if (result == null) continue;
                    NamespacedKey key = new NamespacedKey(plugin, "shapeless_" + id.toLowerCase());
                    ShapelessRecipe recipe = new ShapelessRecipe(key, result);
                    for (String line : shapeless.getStringList(id + ".ingredients")) {
                        String[] parts = line.split(":");
                        Material material = Material.matchMaterial(parts[0].trim());
                        if (material == null) continue;
                        recipe.addIngredient(parts.length > 1 ? Integer.parseInt(parts[1].trim()) : 1, material);
                    }
                    register(key, recipe);
                } catch (IllegalArgumentException ex) {
                    plugin.getLogger().warning("custom-recipes: bad shapeless recipe '" + id + "': " + ex.getMessage());
                }
            }
        }

        ConfigurationSection furnace = config.getConfigurationSection("furnace");
        if (furnace != null) {
            for (String id : furnace.getKeys(false)) {
                ItemStack result = ItemParser.parse(plugin, furnace.getString(id + ".result", ""), "recipe " + id);
                Material input = Material.matchMaterial(furnace.getString(id + ".input", ""));
                if (result == null || input == null) continue;
                NamespacedKey key = new NamespacedKey(plugin, "furnace_" + id.toLowerCase());
                register(key, new FurnaceRecipe(key, result, input,
                        (float) furnace.getDouble(id + ".experience", 0.5), furnace.getInt(id + ".cooking-time", 200)));
            }
        }
    }

    private void register(NamespacedKey key, org.bukkit.inventory.Recipe recipe) {
        if (Bukkit.addRecipe(recipe)) registered.add(key);
    }

    private void unregister() {
        for (NamespacedKey key : registered) Bukkit.removeRecipe(key);
        registered.clear();
    }

    @Override
    protected void onStop() {
        unregister();
    }
}
