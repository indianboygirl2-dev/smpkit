package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.title.Title;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import java.time.Duration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** /freeze <player> and /freeze all (everyone except players with smpkit.freeze.bypass). */
public final class FreezeFeature extends Feature {

    private static final String BYPASS = "smpkit.freeze.bypass";

    private final Set<UUID> frozen = new HashSet<>();
    private boolean globalFreeze;
    private boolean blockCommands;

    public FreezeFeature(SMPKit plugin) {
        super(plugin);
    }

    @Override
    public String key() { return "freeze"; }

    @Override public org.bukkit.Material icon() { return org.bukkit.Material.BLUE_ICE; }
    @Override public String title() { return "Freeze"; }
    @Override public String description() { return "Freeze players or everyone except staff."; }

    @Override
    public List<String> commands() { return List.of("freeze"); }

    @Override
    protected void load(ConfigurationSection config) {
        blockCommands = config.getBoolean("block-commands", false);
    }

    @Override
    protected void onStop() {
        frozen.clear();
        globalFreeze = false;
    }

    private boolean isFrozen(Player player) {
        return frozen.contains(player.getUniqueId()) || (globalFreeze && !player.hasPermission(BYPASS));
    }

    @Override
    public boolean handleCommand(CommandSender sender, String command, String[] args) {
        if (args.length < 1) {
            plugin.messages().send(sender, "usage-freeze");
            return true;
        }

        if (args[0].equalsIgnoreCase("all")) {
            globalFreeze = !globalFreeze;
            plugin.messages().send(sender, globalFreeze ? "freeze-all-on" : "freeze-all-off");
            if (globalFreeze) {
                for (Player player : plugin.getServer().getOnlinePlayers()) {
                    if (!player.hasPermission(BYPASS)) notifyFrozen(player);
                }
            }
            return true;
        }

        Player target = plugin.getServer().getPlayerExact(args[0]);
        if (target == null) {
            plugin.messages().send(sender, "player-not-found");
            return true;
        }
        if (frozen.remove(target.getUniqueId())) {
            plugin.messages().send(sender, "freeze-player-off", Placeholder.unparsed("player", target.getName()));
        } else {
            frozen.add(target.getUniqueId());
            plugin.messages().send(sender, "freeze-player-on", Placeholder.unparsed("player", target.getName()));
            notifyFrozen(target);
        }
        return true;
    }

    private void notifyFrozen(Player player) {
        player.showTitle(Title.title(
                plugin.messages().raw("frozen-title"),
                plugin.messages().raw("frozen-subtitle"),
                Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(3), Duration.ofMillis(500))));
    }

    @Override
    public List<String> tabComplete(CommandSender sender, String command, String[] args) {
        if (args.length != 1) return List.of();
        List<String> options = new java.util.ArrayList<>(onlinePlayers(args[0]));
        if ("all".startsWith(args[0].toLowerCase())) options.add("all");
        return options;
    }

    // ------------------------------------------------------------------ restrictions

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!event.hasChangedPosition() || !isFrozen(event.getPlayer())) return;
        Location from = event.getFrom();
        Location to = event.getTo();
        Location fixed = from.clone();
        fixed.setYaw(to.getYaw());       // looking around is still allowed
        fixed.setPitch(to.getPitch());
        event.setTo(fixed);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (isFrozen(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (isFrozen(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (isFrozen(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player && isFrozen(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (blockCommands && isFrozen(event.getPlayer())) {
            event.setCancelled(true);
            plugin.messages().send(event.getPlayer(), "frozen-blocked");
        }
    }
}
