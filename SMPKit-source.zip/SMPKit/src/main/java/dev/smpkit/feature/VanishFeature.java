package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** /vanish: hide from other players, silent join/quit, mobs ignore you. */
public final class VanishFeature extends Feature {

    private static final String SEE_PERMISSION = "smpkit.vanish.see";

    private final Set<UUID> vanished = new HashSet<>();
    private boolean fakeMessages;
    private boolean canPickup;

    public VanishFeature(SMPKit plugin) {
        super(plugin);
    }

    @Override
    public String key() { return "vanish"; }

    @Override public org.bukkit.Material icon() { return org.bukkit.Material.POTION; }
    @Override public String title() { return "Vanish"; }
    @Override public String description() { return "Staff vanish with silent join/quit."; }

    @Override
    public List<String> commands() { return List.of("vanish"); }

    @Override
    protected void load(ConfigurationSection config) {
        fakeMessages = config.getBoolean("fake-join-quit-messages", true);
        canPickup = config.getBoolean("can-pickup-items", false);
    }

    /** Feature switched off or plugin disabled: everyone becomes visible again. */
    @Override
    protected void onStop() {
        for (UUID id : new HashSet<>(vanished)) {
            Player player = plugin.getServer().getPlayer(id);
            if (player != null) show(player);
        }
        vanished.clear();
    }

    @Override
    public boolean handleCommand(CommandSender sender, String command, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "players-only");
            return true;
        }
        if (vanished.remove(player.getUniqueId())) {
            show(player);
            plugin.messages().send(player, "vanish-off");
            if (fakeMessages) broadcastFake("fake-join", player);
        } else {
            vanished.add(player.getUniqueId());
            hide(player);
            plugin.messages().send(player, "vanish-on");
            if (fakeMessages) broadcastFake("fake-quit", player);
        }
        return true;
    }

    private void hide(Player player) {
        for (Player other : plugin.getServer().getOnlinePlayers()) {
            if (other != player && !other.hasPermission(SEE_PERMISSION)) {
                other.hidePlayer(plugin, player);
            }
        }
        player.setSleepingIgnored(true);
    }

    private void show(Player player) {
        for (Player other : plugin.getServer().getOnlinePlayers()) {
            other.showPlayer(plugin, player);
        }
        player.setSleepingIgnored(false);
    }

    private void broadcastFake(String key, Player player) {
        plugin.getServer().broadcast(plugin.messages().raw(key, Placeholder.unparsed("player", player.getName())));
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onJoin(PlayerJoinEvent event) {
        Player joiner = event.getPlayer();

        // hide already-vanished staff from the new player
        if (!joiner.hasPermission(SEE_PERMISSION)) {
            for (UUID id : vanished) {
                Player hidden = plugin.getServer().getPlayer(id);
                if (hidden != null && hidden != joiner) joiner.hidePlayer(plugin, hidden);
            }
        }
        // a vanished player rejoining stays vanished and silent
        if (vanished.contains(joiner.getUniqueId())) {
            event.joinMessage(null);
            hide(joiner);
            plugin.messages().send(joiner, "vanish-reminder");
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onQuit(PlayerQuitEvent event) {
        if (vanished.contains(event.getPlayer().getUniqueId())) {
            event.quitMessage(null);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onTarget(EntityTargetLivingEntityEvent event) {
        if (event.getTarget() instanceof Player player && vanished.contains(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!canPickup && event.getEntity() instanceof Player player && vanished.contains(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }
}
