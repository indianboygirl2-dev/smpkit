package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * /invsee and /ecsee for online players.
 * Without smpkit.invsee.modify the view is read-only.
 */
public final class InvseeFeature extends Feature {

    private final Set<UUID> readOnly = new HashSet<>();

    public InvseeFeature(SMPKit plugin) {
        super(plugin);
    }

    @Override
    public String key() { return "invsee"; }

    @Override public org.bukkit.Material icon() { return org.bukkit.Material.CHEST; }
    @Override public String title() { return "Invsee / Ecsee"; }
    @Override public String description() { return "View or edit inventories and ender chests."; }

    @Override
    public List<String> commands() { return List.of("invsee", "ecsee"); }

    @Override
    protected void onStop() {
        readOnly.clear();
    }

    @Override
    public boolean handleCommand(CommandSender sender, String command, String[] args) {
        if (!(sender instanceof Player viewer)) {
            plugin.messages().send(sender, "players-only");
            return true;
        }
        if (args.length < 1) {
            plugin.messages().send(sender, "usage-invsee", net.kyori.adventure.text.minimessage.tag.resolver.Placeholder.unparsed("command", command));
            return true;
        }
        Player target = plugin.getServer().getPlayerExact(args[0]);
        if (target == null) {
            plugin.messages().send(sender, "player-not-found");
            return true;
        }
        if (target.equals(viewer)) {
            plugin.messages().send(sender, "invsee-self");
            return true;
        }
        if (target.hasPermission("smpkit.invsee.exempt")) {
            plugin.messages().send(sender, "invsee-exempt");
            return true;
        }

        Inventory inventory = command.equals("invsee") ? target.getInventory() : target.getEnderChest();
        viewer.openInventory(inventory);
        // add AFTER opening: opening closes any previous view, which would clear the flag
        if (!viewer.hasPermission("smpkit.invsee.modify")) {
            readOnly.add(viewer.getUniqueId());
        }
        return true;
    }

    @Override
    public List<String> tabComplete(CommandSender sender, String command, String[] args) {
        return args.length == 1 ? onlinePlayers(args[0]) : List.of();
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        if (readOnly.contains(event.getWhoClicked().getUniqueId())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent event) {
        if (readOnly.contains(event.getWhoClicked().getUniqueId())) event.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        readOnly.remove(event.getPlayer().getUniqueId());
    }
}
