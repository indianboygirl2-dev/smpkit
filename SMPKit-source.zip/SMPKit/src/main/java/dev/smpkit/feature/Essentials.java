package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import dev.smpkit.Util;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDismountEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/** Everyday commands: homes, spawn, back, tpa, rtp, heal, broadcast, links, msg/reply, sit. */
public final class Essentials {

    private Essentials() { }

    // ------------------------------------------------------------------------------------------ homes

    public static final class Homes extends SimpleFeature {
        private int maxHomes = 3, delay = 3;

        public Homes(SMPKit plugin) {
            super(plugin, "home", Material.RED_BED, "Homes", "/home, /sethome, /delhome and /homes.");
        }

        @Override public List<String> commands() { return List.of("home", "sethome", "delhome", "homes"); }

        @Override
        protected void load(ConfigurationSection config) {
            maxHomes = config.getInt("max-homes", 3);
            delay = config.getInt("teleport-delay-seconds", 3);
        }

        private String base(Player player) { return "homes." + player.getUniqueId(); }

        @Override
        public boolean handleCommand(CommandSender sender, String command, String[] args) {
            Player player = playerOnly(sender);
            if (player == null) return true;
            String name = (args.length > 0 ? args[0] : "home").toLowerCase(Locale.ROOT);
            String path = base(player) + "." + name;

            switch (command) {
                case "sethome" -> {
                    if (!name.matches("[a-z0-9_-]{1,16}")) {
                        plugin.messages().send(player, "home-invalid");
                        return true;
                    }
                    Set<String> existing = plugin.data().keys(base(player));
                    if (!existing.contains(name) && existing.size() >= maxHomes && !player.hasPermission("smpkit.homes.unlimited")) {
                        plugin.messages().send(player, "home-limit", ph("max", maxHomes));
                        return true;
                    }
                    plugin.data().set(path, player.getLocation());
                    plugin.messages().send(player, "home-set", ph("name", name));
                }
                case "delhome" -> {
                    if (!plugin.data().contains(path)) {
                        plugin.messages().send(player, "home-missing");
                        return true;
                    }
                    plugin.data().set(path, null);
                    plugin.messages().send(player, "home-deleted", ph("name", name));
                }
                case "homes" -> plugin.messages().send(player, "homes-list", ph("homes", String.join(", ", plugin.data().keys(base(player)))));
                default -> {
                    Location location = plugin.data().getLocation(path);
                    if (location == null) {
                        plugin.messages().send(player, "home-missing");
                        return true;
                    }
                    Util.teleport(plugin, player, location, delay);
                }
            }
            return true;
        }

        @Override
        public List<String> tabComplete(CommandSender sender, String command, String[] args) {
            if (args.length == 1 && sender instanceof Player player && !command.equals("homes")) {
                return filter(plugin.data().keys(base(player)), args[0]);
            }
            return List.of();
        }
    }

    // ------------------------------------------------------------------------------------------ spawn / back

    public static final class Spawn extends SimpleFeature {
        private int delay = 3;

        public Spawn(SMPKit plugin) {
            super(plugin, "spawn", Material.HEART_OF_THE_SEA, "Spawn", "/spawn and /setspawn.");
        }

        @Override public List<String> commands() { return List.of("spawn", "setspawn"); }

        @Override
        protected void load(ConfigurationSection config) {
            delay = config.getInt("teleport-delay-seconds", 3);
        }

        @Override
        public boolean handleCommand(CommandSender sender, String command, String[] args) {
            Player player = playerOnly(sender);
            if (player == null) return true;
            if (command.equals("setspawn")) {
                plugin.data().set("spawn", player.getLocation());
                plugin.messages().send(player, "spawn-set");
                return true;
            }
            Location spawn = plugin.data().getLocation("spawn");
            if (spawn == null) spawn = Bukkit.getWorlds().get(0).getSpawnLocation();
            Util.teleport(plugin, player, spawn, delay);
            return true;
        }
    }

    public static final class Back extends SimpleFeature {
        private final Map<UUID, Location> last = new HashMap<>();
        private int delay = 3;

        public Back(SMPKit plugin) {
            super(plugin, "back", Material.RECOVERY_COMPASS, "Back", "/back returns you to your previous location or death point.");
        }

        @Override public List<String> commands() { return List.of("back"); }

        @Override
        protected void load(ConfigurationSection config) {
            delay = config.getInt("teleport-delay-seconds", 3);
        }

        @Override
        protected void onStop() {
            last.clear();
        }

        @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
        public void onTeleport(PlayerTeleportEvent event) {
            PlayerTeleportEvent.TeleportCause cause = event.getCause();
            if (cause == PlayerTeleportEvent.TeleportCause.COMMAND || cause == PlayerTeleportEvent.TeleportCause.PLUGIN) {
                last.put(event.getPlayer().getUniqueId(), event.getFrom());
            }
        }

        @EventHandler(priority = EventPriority.MONITOR)
        public void onDeath(PlayerDeathEvent event) {
            if (event.getEntity().hasPermission("smpkit.back.death")) {
                last.put(event.getEntity().getUniqueId(), event.getEntity().getLocation());
            }
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent event) {
            last.remove(event.getPlayer().getUniqueId());
        }

        @Override
        public boolean handleCommand(CommandSender sender, String command, String[] args) {
            Player player = playerOnly(sender);
            if (player == null) return true;
            Location location = last.get(player.getUniqueId());
            if (location == null) plugin.messages().send(player, "back-none");
            else Util.teleport(plugin, player, location, delay);
            return true;
        }
    }

    // ------------------------------------------------------------------------------------------ tpa

    public static final class Tpa extends SimpleFeature {
        private record Request(UUID from, boolean here, long expires) { }

        private final Map<UUID, Request> pending = new HashMap<>();
        private long timeoutMillis = 60_000;
        private int delay = 3;

        public Tpa(SMPKit plugin) {
            super(plugin, "tpa", Material.ENDER_PEARL, "TPA", "/tpa, /tpahere, /tpaccept and /tpdeny.");
        }

        @Override public List<String> commands() { return List.of("tpa", "tpahere", "tpaccept", "tpdeny"); }

        @Override
        protected void load(ConfigurationSection config) {
            timeoutMillis = config.getLong("timeout-seconds", 60) * 1000L;
            delay = config.getInt("teleport-delay-seconds", 3);
        }

        @Override
        protected void onStop() {
            pending.clear();
        }

        @Override
        public boolean handleCommand(CommandSender sender, String command, String[] args) {
            Player player = playerOnly(sender);
            if (player == null) return true;

            if (command.equals("tpa") || command.equals("tpahere")) {
                if (args.length < 1) {
                    plugin.messages().send(player, "usage-tpa", ph("command", command));
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null || target.equals(player)) {
                    plugin.messages().send(player, "player-not-found");
                    return true;
                }
                boolean here = command.equals("tpahere");
                pending.put(target.getUniqueId(), new Request(player.getUniqueId(), here, System.currentTimeMillis() + timeoutMillis));
                plugin.messages().send(player, "tpa-sent", ph("player", target.getName()));
                plugin.messages().send(target, here ? "tpahere-received" : "tpa-received", ph("player", player.getName()));
                return true;
            }

            Request request = pending.remove(player.getUniqueId());
            if (request == null) {
                plugin.messages().send(player, "tpa-none");
                return true;
            }
            Player requester = Bukkit.getPlayer(request.from());
            if (request.expires() < System.currentTimeMillis() || requester == null) {
                plugin.messages().send(player, "tpa-expired");
                return true;
            }
            if (command.equals("tpdeny")) {
                plugin.messages().send(player, "tpa-denied");
                plugin.messages().send(requester, "tpa-denied-other", ph("player", player.getName()));
                return true;
            }
            if (request.here()) Util.teleport(plugin, player, requester.getLocation(), delay);
            else Util.teleport(plugin, requester, player.getLocation(), delay);
            return true;
        }

        @Override
        public List<String> tabComplete(CommandSender sender, String command, String[] args) {
            return args.length == 1 && (command.equals("tpa") || command.equals("tpahere")) ? onlinePlayers(args[0]) : List.of();
        }
    }

    // ------------------------------------------------------------------------------------------ rtp

    public static final class Rtp extends SimpleFeature {
        private static final Set<Material> UNSAFE = EnumSet.of(Material.CACTUS, Material.MAGMA_BLOCK, Material.FIRE,
                Material.POWDER_SNOW, Material.SWEET_BERRY_BUSH, Material.LAVA, Material.WATER);

        private final Map<UUID, Long> cooldowns = new HashMap<>();
        private final Random random = new Random();
        private int minRadius = 200, maxRadius = 3000, cooldownSeconds = 300, delay = 3;

        public Rtp(SMPKit plugin) {
            super(plugin, "rtp", Material.COMPASS, "RTP", "/rtp teleports you to a random safe location.");
        }

        @Override public List<String> commands() { return List.of("rtp"); }

        @Override
        protected void load(ConfigurationSection config) {
            minRadius = config.getInt("min-radius", 200);
            maxRadius = Math.max(minRadius + 1, config.getInt("max-radius", 3000));
            cooldownSeconds = config.getInt("cooldown-seconds", 300);
            delay = config.getInt("teleport-delay-seconds", 3);
        }

        @Override
        public boolean handleCommand(CommandSender sender, String command, String[] args) {
            Player player = playerOnly(sender);
            if (player == null) return true;
            Long until = cooldowns.get(player.getUniqueId());
            if (until != null && until > System.currentTimeMillis() && !player.hasPermission("smpkit.rtp.bypass")) {
                plugin.messages().send(player, "rtp-cooldown", ph("time", Util.duration(until - System.currentTimeMillis())));
                return true;
            }
            World world = player.getWorld().getEnvironment() == World.Environment.NORMAL
                    ? player.getWorld() : Bukkit.getWorlds().get(0);
            plugin.messages().send(player, "rtp-searching");
            attempt(player, world, 0);
            return true;
        }

        private void attempt(Player player, World world, int tries) {
            if (tries >= 12) {
                plugin.messages().send(player, "rtp-failed");
                return;
            }
            Location center = world.getSpawnLocation();
            double angle = random.nextDouble() * Math.PI * 2;
            double distance = minRadius + random.nextDouble() * (maxRadius - minRadius);
            int x = (int) (center.getX() + Math.cos(angle) * distance);
            int z = (int) (center.getZ() + Math.sin(angle) * distance);

            world.getChunkAtAsync(x >> 4, z >> 4).thenAccept(chunk -> Bukkit.getScheduler().runTask(plugin, () -> {
                int y = world.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
                Block ground = world.getBlockAt(x, y, z);
                Location destination = new Location(world, x + 0.5, y + 1, z + 0.5);
                if (ground.isLiquid() || UNSAFE.contains(ground.getType()) || !world.getWorldBorder().isInside(destination)) {
                    attempt(player, world, tries + 1);
                    return;
                }
                cooldowns.put(player.getUniqueId(), System.currentTimeMillis() + cooldownSeconds * 1000L);
                Util.teleport(plugin, player, destination, delay);
            }));
        }
    }

    // ------------------------------------------------------------------------------------------ small commands

    public static final class Heal extends SimpleFeature {
        public Heal(SMPKit plugin) {
            super(plugin, "heal", Material.GLISTERING_MELON_SLICE, "Heal", "/heal restores health and hunger.");
        }

        @Override public List<String> commands() { return List.of("heal"); }

        @Override
        public boolean handleCommand(CommandSender sender, String command, String[] args) {
            Player target;
            if (args.length > 0) {
                target = Bukkit.getPlayerExact(args[0]);
                if (target == null) {
                    plugin.messages().send(sender, "player-not-found");
                    return true;
                }
            } else {
                target = playerOnly(sender);
                if (target == null) return true;
            }
            var max = target.getAttribute(Attribute.MAX_HEALTH);
            target.setHealth(max == null ? 20.0 : max.getValue());
            target.setFoodLevel(20);
            target.setSaturation(20f);
            target.setFireTicks(0);
            plugin.messages().send(target, "heal-done");
            if (!target.equals(sender)) plugin.messages().send(sender, "heal-other", ph("player", target.getName()));
            return true;
        }

        @Override
        public List<String> tabComplete(CommandSender sender, String command, String[] args) {
            return args.length == 1 ? onlinePlayers(args[0]) : List.of();
        }
    }

    public static final class Broadcast extends SimpleFeature {
        public Broadcast(SMPKit plugin) {
            super(plugin, "broadcast", Material.BELL, "Broadcast", "/broadcast <message> announces to everyone (MiniMessage allowed).");
        }

        @Override public List<String> commands() { return List.of("broadcast"); }

        @Override
        public boolean handleCommand(CommandSender sender, String command, String[] args) {
            if (args.length == 0) return false;
            plugin.getServer().broadcast(plugin.messages().raw("broadcast-format",
                    Placeholder.parsed("message", String.join(" ", args))));
            return true;
        }
    }

    public static final class Links extends SimpleFeature {
        private String discord = "", store = "";

        public Links(SMPKit plugin) {
            super(plugin, "links", Material.WRITABLE_BOOK, "Discord / Store", "/discord and /store send your links.");
        }

        @Override public List<String> commands() { return List.of("discord", "store"); }

        @Override
        protected void load(ConfigurationSection config) {
            discord = config.getString("discord-url", "");
            store = config.getString("store-url", "");
        }

        @Override
        public boolean handleCommand(CommandSender sender, String command, String[] args) {
            String url = command.equals("discord") ? discord : store;
            if (url.isBlank()) {
                plugin.messages().send(sender, "link-not-set");
                return true;
            }
            sender.sendMessage(plugin.messages().prefixed("link-" + command, Placeholder.parsed("url", url)));
            return true;
        }
    }

    public static final class Msg extends SimpleFeature {
        private final Map<UUID, UUID> lastContact = new HashMap<>();

        public Msg(SMPKit plugin) {
            super(plugin, "msg", Material.PAPER, "Private Messages", "/msg and /reply.");
        }

        @Override public List<String> commands() { return List.of("msg", "reply"); }

        @Override
        protected void onStop() {
            lastContact.clear();
        }

        @Override
        public boolean handleCommand(CommandSender sender, String command, String[] args) {
            Player player = playerOnly(sender);
            if (player == null) return true;
            Player target;
            String text;
            if (command.equals("msg")) {
                if (args.length < 2) {
                    plugin.messages().send(player, "usage-msg");
                    return true;
                }
                target = Bukkit.getPlayerExact(args[0]);
                text = String.join(" ", List.of(args).subList(1, args.length));
            } else {
                UUID id = lastContact.get(player.getUniqueId());
                target = id == null ? null : Bukkit.getPlayer(id);
                if (target == null) {
                    plugin.messages().send(player, "reply-none");
                    return true;
                }
                text = String.join(" ", args);
                if (text.isBlank()) return false;
            }
            if (target == null) {
                plugin.messages().send(player, "player-not-found");
                return true;
            }
            lastContact.put(player.getUniqueId(), target.getUniqueId());
            lastContact.put(target.getUniqueId(), player.getUniqueId());
            player.sendMessage(plugin.messages().raw("msg-to", ph("player", target.getName()), ph("message", text)));
            target.sendMessage(plugin.messages().raw("msg-from", ph("player", player.getName()), ph("message", text)));
            return true;
        }

        @Override
        public List<String> tabComplete(CommandSender sender, String command, String[] args) {
            return command.equals("msg") && args.length == 1 ? onlinePlayers(args[0]) : List.of();
        }
    }

    /** /sit spawns an invisible seat under you. */
    public static final class Sit extends SimpleFeature {
        private final Map<UUID, ArmorStand> seats = new HashMap<>();
        private double yOffset = -0.25;

        public Sit(SMPKit plugin) {
            super(plugin, "sit", Material.OAK_STAIRS, "Sit", "/sit lets players sit down.");
        }

        @Override public List<String> commands() { return List.of("sit"); }

        @Override
        protected void load(ConfigurationSection config) {
            yOffset = config.getDouble("y-offset", -0.25);
        }

        @Override
        protected void onStop() {
            for (ArmorStand stand : seats.values()) stand.remove();
            seats.clear();
        }

        @Override
        public boolean handleCommand(CommandSender sender, String command, String[] args) {
            Player player = playerOnly(sender);
            if (player == null) return true;
            ArmorStand existing = seats.remove(player.getUniqueId());
            if (existing != null) {
                existing.remove();
                return true;
            }
            if (!player.isOnGround() || player.isInsideVehicle()) {
                plugin.messages().send(player, "sit-air");
                return true;
            }
            ArmorStand stand = player.getWorld().spawn(player.getLocation().add(0, yOffset, 0), ArmorStand.class, s -> {
                s.setInvisible(true);
                s.setMarker(true);
                s.setGravity(false);
                s.setInvulnerable(true);
                s.setPersistent(false);
            });
            stand.addPassenger(player);
            seats.put(player.getUniqueId(), stand);
            return true;
        }

        @EventHandler
        public void onDismount(EntityDismountEvent event) {
            if (!(event.getEntity() instanceof Player player)) return;
            ArmorStand stand = seats.get(player.getUniqueId());
            if (stand != null && stand.equals(event.getDismounted())) {
                seats.remove(player.getUniqueId());
                stand.remove();
                player.teleport(player.getLocation().add(0, 0.6, 0));
            }
        }

        @EventHandler
        public void onQuit(PlayerQuitEvent event) {
            ArmorStand stand = seats.remove(event.getPlayer().getUniqueId());
            if (stand != null) stand.remove();
        }
    }
}
