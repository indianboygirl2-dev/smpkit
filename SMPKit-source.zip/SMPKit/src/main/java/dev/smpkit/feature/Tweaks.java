package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import io.papermc.paper.event.player.PlayerTradeEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.AbstractVillager;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.entity.VillagerCareerChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.MerchantRecipe;
import org.bukkit.inventory.view.AnvilView;

import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/** World and mechanics tweaks. */
public final class Tweaks {

    private Tweaks() { }

    // ------------------------------------------------------------------------------------------ blocks

    public static final class BlockDecay extends SimpleFeature {
        private final Map<Material, Integer> seconds = new EnumMap<>(Material.class);

        public BlockDecay(SMPKit plugin) {
            super(plugin, "block-decay", Material.COBWEB, "Block Decay",
                    "Chosen blocks disappear a few seconds after being placed.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            seconds.clear();
            ConfigurationSection section = config.getConfigurationSection("blocks");
            if (section == null) return;
            for (String name : section.getKeys(false)) {
                Material material = Material.matchMaterial(name);
                if (material != null) seconds.put(material, section.getInt(name));
            }
        }

        @EventHandler(ignoreCancelled = true)
        public void onPlace(BlockPlaceEvent event) {
            Block block = event.getBlockPlaced();
            Material type = block.getType();
            Integer delay = seconds.get(type);
            if (delay == null) return;
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (block.getType() == type) block.setType(Material.AIR);
            }, delay * 20L);
        }
    }

    public static final class NoFallingBlocks extends SimpleFeature {
        public NoFallingBlocks(SMPKit plugin) {
            super(plugin, "no-falling-blocks", Material.SAND, "No Falling Blocks",
                    "Sand, gravel and other blocks no longer fall.");
        }

        @EventHandler(ignoreCancelled = true)
        public void onChange(EntityChangeBlockEvent event) {
            if (event.getEntity() instanceof FallingBlock && event.getTo().isAir()) event.setCancelled(true);
        }
    }

    public static final class FireControl extends SimpleFeature {
        private boolean stopSpread, stopBurn;

        public FireControl(SMPKit plugin) {
            super(plugin, "fire-control", Material.FLINT_AND_STEEL, "Fire Control",
                    "Stops fire from spreading and burning blocks.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            stopSpread = config.getBoolean("stop-spread", true);
            stopBurn = config.getBoolean("stop-burn", true);
        }

        @EventHandler(ignoreCancelled = true)
        public void onSpread(BlockSpreadEvent event) {
            if (stopSpread && event.getSource().getType() == Material.FIRE) event.setCancelled(true);
        }

        @EventHandler(ignoreCancelled = true)
        public void onIgnite(BlockIgniteEvent event) {
            if (stopSpread && event.getCause() == BlockIgniteEvent.IgniteCause.SPREAD) event.setCancelled(true);
        }

        @EventHandler(ignoreCancelled = true)
        public void onBurn(BlockBurnEvent event) {
            if (stopBurn) event.setCancelled(true);
        }
    }

    public static final class AppleDrops extends SimpleFeature {
        private final Random random = new Random();
        private double chance = 2.0;

        public AppleDrops(SMPKit plugin) {
            super(plugin, "apple-drops", Material.APPLE, "Apple Drops",
                    "Leaves of every tree type can drop apples.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            chance = config.getDouble("chance-percent", 2.0);
        }

        private void maybeDrop(Block block) {
            if (random.nextDouble() * 100.0 < chance) {
                block.getWorld().dropItemNaturally(block.getLocation().add(0.5, 0.5, 0.5), new ItemStack(Material.APPLE));
            }
        }

        @EventHandler(ignoreCancelled = true)
        public void onBreak(BlockBreakEvent event) {
            if (Tag.LEAVES.isTagged(event.getBlock().getType()) && event.isDropItems()
                    && event.getPlayer().getGameMode() == org.bukkit.GameMode.SURVIVAL) {
                maybeDrop(event.getBlock());
            }
        }

        @EventHandler(ignoreCancelled = true)
        public void onDecay(LeavesDecayEvent event) {
            maybeDrop(event.getBlock());
        }
    }

    public static final class BlockMechanics extends SimpleFeature {
        private boolean placing, breaking;

        public BlockMechanics(SMPKit plugin) {
            super(plugin, "block-mechanics", Material.STONE_BRICKS, "Block Mechanics",
                    "Globally allow or forbid placing / breaking blocks (set in config).");
        }

        @Override
        protected void load(ConfigurationSection config) {
            placing = config.getBoolean("placing", true);
            breaking = config.getBoolean("breaking", true);
        }

        @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
        public void onPlace(BlockPlaceEvent event) {
            if (!placing && !event.getPlayer().hasPermission("smpkit.blockmechanics.bypass")) {
                event.setCancelled(true);
                plugin.messages().send(event.getPlayer(), "action-disabled");
            }
        }

        @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
        public void onBreak(BlockBreakEvent event) {
            if (!breaking && !event.getPlayer().hasPermission("smpkit.blockmechanics.bypass")) {
                event.setCancelled(true);
                plugin.messages().send(event.getPlayer(), "action-disabled");
            }
        }
    }

    // ------------------------------------------------------------------------------------------ anvils

    /** Removes the "Too Expensive!" cap. */
    public static final class AnvilFix extends SimpleFeature {
        public AnvilFix(SMPKit plugin) {
            super(plugin, "anvil-fix", Material.ANVIL, "Too Expensive Anvil Fix",
                    "Anvil repairs never show 'Too Expensive!' (cost is capped at 39 levels).");
        }

        @EventHandler(priority = EventPriority.HIGHEST)
        public void onPrepare(PrepareAnvilEvent event) {
            if (event.getResult() == null) return;
            AnvilView view = event.getView();
            view.setMaximumRepairCost(Integer.MAX_VALUE);
            if (view.getRepairCost() >= 40) view.setRepairCost(39);
        }
    }

    /** Anvils never get damaged or destroyed. */
    public static final class UnbreakableAnvils extends SimpleFeature {
        public UnbreakableAnvils(SMPKit plugin) {
            super(plugin, "unbreakable-anvils", Material.CHIPPED_ANVIL, "Unbreakable Anvils",
                    "Anvils never chip, damage or break.");
        }

        @EventHandler
        public void onClick(InventoryClickEvent event) {
            if (!(event.getInventory() instanceof AnvilInventory anvil) || event.getRawSlot() != 2) return;
            Location location = anvil.getLocation();
            if (location == null) return;
            Block block = location.getBlock();
            if (!Tag.ANVIL.isTagged(block.getType())) return;
            BlockData saved = block.getBlockData();
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                if (!block.getBlockData().equals(saved)) block.setBlockData(saved);
            });
        }
    }

    // ------------------------------------------------------------------------------------------ mobs & entities

    public static final class MobDisabler extends SimpleFeature {
        private final Set<String> mobs = new HashSet<>();
        private boolean allowEggs;

        public MobDisabler(SMPKit plugin) {
            super(plugin, "mob-disabler", Material.SPAWNER, "Mob Disabler", "Stop chosen mobs from spawning.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            mobs.clear();
            for (String name : config.getStringList("mobs")) mobs.add(name.trim().toUpperCase(Locale.ROOT));
            allowEggs = config.getBoolean("allow-spawn-eggs", true);
        }

        @EventHandler(ignoreCancelled = true)
        public void onSpawn(CreatureSpawnEvent event) {
            if (!mobs.contains(event.getEntityType().name())) return;
            CreatureSpawnEvent.SpawnReason reason = event.getSpawnReason();
            if (reason == CreatureSpawnEvent.SpawnReason.CUSTOM || reason == CreatureSpawnEvent.SpawnReason.COMMAND) return;
            if (allowEggs && (reason == CreatureSpawnEvent.SpawnReason.SPAWNER_EGG
                    || reason == CreatureSpawnEvent.SpawnReason.DISPENSE_EGG)) return;
            event.setCancelled(true);
        }
    }

    public static final class ArmorStandArms extends SimpleFeature {
        public ArmorStandArms(SMPKit plugin) {
            super(plugin, "armor-stand-arms", Material.ARMOR_STAND, "Armor Stand Arms",
                    "Newly placed armor stands have arms.");
        }

        @EventHandler
        public void onSpawn(EntitySpawnEvent event) {
            if (event.getEntity() instanceof ArmorStand stand) stand.setArms(true);
        }
    }

    public static final class HappyGhastSpeed extends SimpleFeature {
        private final NamespacedKey key;
        private double multiplier = 1.0;

        public HappyGhastSpeed(SMPKit plugin) {
            super(plugin, "happy-ghast-speed", Material.GHAST_TEAR, "Happy Ghast Speed",
                    "Multiply the speed of happy ghasts.");
            this.key = new NamespacedKey(plugin, "happy_ghast_speed");
        }

        @Override
        protected void load(ConfigurationSection config) {
            multiplier = config.getDouble("multiplier", 2.0);
            for (World world : plugin.getServer().getWorlds()) {
                for (Entity entity : world.getEntities()) modify(entity);
            }
        }

        @Override
        protected void onStop() {
            multiplier = 1.0;
            for (World world : plugin.getServer().getWorlds()) {
                for (Entity entity : world.getEntities()) modify(entity);
            }
        }

        private void modify(Entity entity) {
            if (!entity.getType().name().equals("HAPPY_GHAST") || !(entity instanceof LivingEntity living)) return;
            for (Attribute attribute : new Attribute[]{Attribute.FLYING_SPEED, Attribute.MOVEMENT_SPEED}) {
                AttributeInstance instance = living.getAttribute(attribute);
                if (instance == null) continue;
                for (AttributeModifier modifier : List.copyOf(instance.getModifiers())) {
                    if (key.equals(modifier.getKey())) instance.removeModifier(modifier);
                }
                if (multiplier != 1.0) {
                    instance.addModifier(new AttributeModifier(key, multiplier - 1.0, AttributeModifier.Operation.MULTIPLY_SCALAR_1));
                }
            }
        }

        @EventHandler
        public void onSpawn(EntitySpawnEvent event) {
            modify(event.getEntity());
        }

        @EventHandler
        public void onLoad(EntitiesLoadEvent event) {
            for (Entity entity : event.getEntities()) modify(entity);
        }
    }

    // ------------------------------------------------------------------------------------------ villagers

    public static final class InfiniteRestock extends SimpleFeature {
        public InfiniteRestock(SMPKit plugin) {
            super(plugin, "infinite-restock", Material.EMERALD, "Infinite Restock",
                    "Villager and wandering trader trades never run out.");
        }

        @EventHandler
        public void onInteract(PlayerInteractEntityEvent event) {
            if (!(event.getRightClicked() instanceof AbstractVillager villager)) return;
            List<MerchantRecipe> recipes = villager.getRecipes();
            boolean changed = false;
            for (MerchantRecipe recipe : recipes) {
                if (recipe.getUses() > 0) {
                    recipe.setUses(0);
                    changed = true;
                }
            }
            if (changed) villager.setRecipes(recipes);
        }

        /** Keeps trades unlocked right after a trade as well. */
        @EventHandler
        public void onTrade(PlayerTradeEvent event) {
            AbstractVillager villager = event.getVillager();
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                List<MerchantRecipe> recipes = villager.getRecipes();
                for (MerchantRecipe recipe : recipes) recipe.setUses(0);
                villager.setRecipes(recipes);
            });
        }
    }

    public static final class DisableTrades extends SimpleFeature {
        public DisableTrades(SMPKit plugin) {
            super(plugin, "disable-villager-trades", Material.BARRIER, "Disable Villager Trades",
                    "Players can't trade with villagers or wandering traders.");
        }

        @EventHandler(ignoreCancelled = true)
        public void onInteract(PlayerInteractEntityEvent event) {
            if (event.getRightClicked() instanceof AbstractVillager
                    && !event.getPlayer().hasPermission("smpkit.villagertrades.bypass")) {
                event.setCancelled(true);
                plugin.messages().send(event.getPlayer(), "action-disabled");
            }
        }
    }

    public static final class BlockTradeCycling extends SimpleFeature {
        public BlockTradeCycling(SMPKit plugin) {
            super(plugin, "block-trade-cycling", Material.LECTERN, "Block Trade Cycling",
                    "Villagers keep their job when the workstation is removed.");
        }

        @EventHandler(ignoreCancelled = true)
        public void onCareer(VillagerCareerChangeEvent event) {
            if (event.getReason() == VillagerCareerChangeEvent.ChangeReason.LOSING_JOB) event.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------------------------------ server settings

    public static final class RenderDistance extends SimpleFeature {
        public RenderDistance(SMPKit plugin) {
            super(plugin, "render-distance", Material.SPYGLASS, "Render Distance",
                    "Set the server view and simulation distance.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            int view = config.getInt("view-distance", 0);
            int simulation = config.getInt("simulation-distance", 0);
            for (World world : plugin.getServer().getWorlds()) {
                if (view >= 2) world.setViewDistance(view);
                if (simulation >= 2) world.setSimulationDistance(simulation);
            }
        }
    }

    public static final class LocatorBar extends SimpleFeature {
        public LocatorBar(SMPKit plugin) {
            super(plugin, "locator-bar", Material.COMPASS, "Locator Bar",
                    "Show or hide the player locator bar (set 'show' in config).");
        }

        @Override
        protected void load(ConfigurationSection config) {
            String value = String.valueOf(config.getBoolean("show", false));
            // The game rule was renamed in 1.21.11, so try both spellings.
            if (!Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "gamerule locator_bar " + value)) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "gamerule locatorBar " + value);
            }
        }
    }

    /** One sleeping player is enough to skip the night. */
    public static final class OnePlayerSleep extends SimpleFeature {
        public OnePlayerSleep(SMPKit plugin) {
            super(plugin, "one-player-sleep", Material.RED_BED, "One Player Sleep",
                    "A single sleeping player skips the night.");
        }

        @EventHandler(ignoreCancelled = true)
        public void onBed(PlayerBedEnterEvent event) {
            if (event.getBedEnterResult() != PlayerBedEnterEvent.BedEnterResult.OK) return;
            Player player = event.getPlayer();
            World world = player.getWorld();
            if (world.getEnvironment() != World.Environment.NORMAL) return;
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline() || !player.isSleeping()) return;
                world.setTime(0);
                world.setStorm(false);
                world.setThundering(false);
            }, 101L);
        }
    }
}
