package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.GameMode;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Combat tag: blocks escape commands and punishes combat logging. */
public final class CombatFeature extends Feature {

    private final Map<UUID, Long> tagged = new HashMap<>();
    private final Set<String> blockedCommands = new HashSet<>();
    private BukkitTask task;

    private long durationMs;
    private boolean killOnLogout;
    private boolean tagOnProjectile;
    private boolean disableElytra;
    private boolean actionBar;
    private boolean ignoreCreative;

    public CombatFeature(SMPKit plugin) {
        super(plugin);
    }

    @Override
    public String key() { return "combat"; }

    @Override public org.bukkit.Material icon() { return org.bukkit.Material.DIAMOND_SWORD; }
    @Override public String title() { return "Combat Rules"; }
    @Override public String description() { return "Combat tag, blocked commands, logout punishment."; }

    @Override
    protected void load(ConfigurationSection config) {
        durationMs = config.getLong("duration-seconds", 20) * 1000L;
        killOnLogout = config.getBoolean("kill-on-logout", true);
        tagOnProjectile = config.getBoolean("tag-on-projectile", true);
        disableElytra = config.getBoolean("disable-elytra", true);
        actionBar = config.getBoolean("show-actionbar", true);
        ignoreCreative = config.getBoolean("ignore-creative", true);
        blockedCommands.clear();
        for (String cmd : config.getStringList("blocked-commands")) {
            blockedCommands.add(cmd.toLowerCase(Locale.ROOT).replaceFirst("^/", ""));
        }
    }

    @Override
    protected void onStart() {
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 10L, 10L);
    }

    @Override
    protected void onStop() {
        if (task != null) task.cancel();
        tagged.clear();
    }

    private void tick() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, Long>> it = tagged.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Long> entry = it.next();
            Player player = plugin.getServer().getPlayer(entry.getKey());
            if (player == null) {
                it.remove();
                continue;
            }
            long left = entry.getValue() - now;
            if (left <= 0) {
                it.remove();
                plugin.messages().send(player, "combat-ended");
                if (actionBar) player.sendActionBar(Component.empty());
                continue;
            }
            if (actionBar) {
                player.sendActionBar(plugin.messages().raw("combat-actionbar",
                        Placeholder.unparsed("seconds", String.valueOf((left + 999) / 1000))));
            }
        }
    }

    private boolean isTagged(UUID id) {
        Long expires = tagged.get(id);
        return expires != null && expires > System.currentTimeMillis();
    }

    private void tag(Player player) {
        if (player.hasPermission("smpkit.combat.bypass")) return;
        if (ignoreCreative && (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR)) return;
        boolean already = isTagged(player.getUniqueId());
        tagged.put(player.getUniqueId(), System.currentTimeMillis() + durationMs);
        if (!already) {
            plugin.messages().send(player, "combat-started");
            if (disableElytra && player.isGliding()) player.setGliding(false);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;

        Player attacker = null;
        if (event.getDamager() instanceof Player direct) {
            attacker = direct;
        } else if (tagOnProjectile && event.getDamager() instanceof Projectile projectile
                && projectile.getShooter() instanceof Player shooter) {
            attacker = shooter;
        }
        if (attacker == null || attacker.equals(victim)) return;

        tag(victim);
        tag(attacker);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        boolean wasTagged = isTagged(player.getUniqueId());
        tagged.remove(player.getUniqueId());
        if (!wasTagged || !killOnLogout || player.isDead()) return;

        plugin.getServer().broadcast(plugin.messages().raw("combat-logout",
                Placeholder.unparsed("player", player.getName())));
        player.setHealth(0.0);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        tagged.remove(event.getEntity().getUniqueId());
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!isTagged(player.getUniqueId())) return;

        String command = event.getMessage().substring(1).split(" ")[0].toLowerCase(Locale.ROOT);
        int colon = command.indexOf(':');
        if (colon >= 0) command = command.substring(colon + 1);

        if (blockedCommands.contains(command)) {
            event.setCancelled(true);
            plugin.messages().send(player, "combat-command-blocked");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onGlide(EntityToggleGlideEvent event) {
        if (disableElytra && event.isGliding()
                && event.getEntity() instanceof Player player
                && isTagged(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }
}
