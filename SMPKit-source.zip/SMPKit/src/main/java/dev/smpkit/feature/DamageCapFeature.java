package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.type.RespawnAnchor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.minecart.ExplosiveMinecart;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Caps damage dealt to players (applied to the final damage, after armor).
 * Respawn anchors are detected when a player right-clicks a charged anchor outside the Nether.
 */
public final class DamageCapFeature extends Feature {

    private record Blast(Location location, int tick) { }

    private final List<Blast> anchorBlasts = new ArrayList<>();
    private final Map<Material, Double> weaponCaps = new EnumMap<>(Material.class);

    private boolean anchorOn, blockOn, crystalOn, tntOn;
    private double anchorMax, blockMax, crystalMax, tntMax;

    public DamageCapFeature(SMPKit plugin) {
        super(plugin);
    }

    @Override public String key() { return "damage-caps"; }
    @Override public Material icon() { return Material.RESPAWN_ANCHOR; }
    @Override public String title() { return "Damage Limiters"; }
    @Override public String description() { return "Cap damage from anchors, crystals, TNT and weapons."; }

    @Override
    protected void load(ConfigurationSection config) {
        anchorOn = config.getBoolean("respawn-anchor.enabled", true);
        anchorMax = config.getDouble("respawn-anchor.max-damage", 10.0);
        blockOn = config.getBoolean("block-explosions.enabled", false);
        blockMax = config.getDouble("block-explosions.max-damage", 20.0);
        crystalOn = config.getBoolean("end-crystal.enabled", false);
        crystalMax = config.getDouble("end-crystal.max-damage", 12.0);
        tntOn = config.getBoolean("tnt.enabled", false);
        tntMax = config.getDouble("tnt.max-damage", 12.0);

        weaponCaps.clear();
        ConfigurationSection weapons = config.getConfigurationSection("weapons");
        if (weapons != null) {
            for (String name : weapons.getKeys(false)) {
                Material material = Material.matchMaterial(name);
                if (material == null) {
                    plugin.getLogger().warning("damage-caps: unknown weapon '" + name + "'");
                    continue;
                }
                weaponCaps.put(material, weapons.getDouble(name));
            }
        }
    }

    @Override
    protected void onStop() {
        anchorBlasts.clear();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (!anchorOn || event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.RESPAWN_ANCHOR) return;
        if (block.getWorld().getEnvironment() == World.Environment.NETHER) return;
        if (!(block.getBlockData() instanceof RespawnAnchor anchor) || anchor.getCharges() <= 0) return;

        anchorBlasts.add(new Blast(block.getLocation().add(0.5, 0.5, 0.5), plugin.getServer().getCurrentTick()));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        switch (event.getCause()) {
            case BLOCK_EXPLOSION -> {
                if (anchorOn && nearRecentAnchorBlast(player)) cap(event, anchorMax);
                if (blockOn) cap(event, blockMax);
            }
            case ENTITY_EXPLOSION -> {
                if (event instanceof EntityDamageByEntityEvent byEntity) {
                    Entity damager = byEntity.getDamager();
                    if (crystalOn && damager instanceof EnderCrystal) cap(event, crystalMax);
                    if (tntOn && (damager instanceof TNTPrimed || damager instanceof ExplosiveMinecart)) cap(event, tntMax);
                }
            }
            case ENTITY_ATTACK, ENTITY_SWEEP_ATTACK -> {
                if (!weaponCaps.isEmpty() && event instanceof EntityDamageByEntityEvent byEntity
                        && byEntity.getDamager() instanceof Player attacker) {
                    Double max = weaponCaps.get(attacker.getInventory().getItemInMainHand().getType());
                    if (max != null) cap(event, max);
                }
            }
            default -> { }
        }
    }

    private boolean nearRecentAnchorBlast(Player player) {
        int now = plugin.getServer().getCurrentTick();
        anchorBlasts.removeIf(blast -> now - blast.tick() > 1);
        for (Blast blast : anchorBlasts) {
            Location loc = blast.location();
            if (loc.getWorld() == player.getWorld() && loc.distanceSquared(player.getLocation()) <= 14 * 14) return true;
        }
        return false;
    }

    private void cap(EntityDamageEvent event, double max) {
        double finalDamage = event.getFinalDamage();
        if (finalDamage > max && finalDamage > 0) {
            event.setDamage(event.getDamage() * (max / finalDamage));
        }
    }
}
