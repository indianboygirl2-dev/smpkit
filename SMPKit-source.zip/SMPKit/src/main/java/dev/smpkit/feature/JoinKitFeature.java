package dev.smpkit.feature;

import dev.smpkit.ItemParser;
import dev.smpkit.SMPKit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Starter kit for first-time joiners (and optionally on every respawn). */
public final class JoinKitFeature extends Feature {

    private final List<ItemStack> kit = new ArrayList<>();
    private boolean giveOnRespawn;

    public JoinKitFeature(SMPKit plugin) {
        super(plugin);
    }

    @Override public String key() { return "join-kit"; }
    @Override public org.bukkit.Material icon() { return org.bukkit.Material.BUNDLE; }
    @Override public String title() { return "Join Kit"; }
    @Override public String description() { return "Starter kit for new players."; }

    @Override
    protected void load(ConfigurationSection config) {
        giveOnRespawn = config.getBoolean("give-on-respawn", false);
        kit.clear();
        for (String line : config.getStringList("items")) {
            ItemStack stack = ItemParser.parse(plugin, line, "join-kit");
            if (stack != null) kit.add(stack);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (!player.hasPlayedBefore()) give(player);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        if (!giveOnRespawn) return;
        Player player = event.getPlayer();
        plugin.getServer().getScheduler().runTask(plugin, () -> give(player));
    }

    private void give(Player player) {
        if (kit.isEmpty()) return;
        for (ItemStack item : kit) {
            player.getInventory().addItem(item.clone())
                    .values()
                    .forEach(left -> player.getWorld().dropItemNaturally(player.getLocation(), left));
        }
        plugin.messages().send(player, "join-kit-given");
    }
}
