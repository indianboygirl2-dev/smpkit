package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TranslatableComponent;
import net.kyori.adventure.text.TranslationArgument;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** PvP quality-of-life and rules. */
public final class Fighting {

    private Fighting() { }

    // ------------------------------------------------------------------------------------------

    public static final class ShieldTweaks extends SimpleFeature {
        private boolean delayFix, maceStun;

        public ShieldTweaks(SMPKit plugin) {
            super(plugin, "shield-tweaks", Material.SHIELD, "Shield Tweaks",
                    "Removes the 5 tick shield delay and lets maces stun shields.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            delayFix = config.getBoolean("delay-fix", true);
            maceStun = config.getBoolean("mace-stuns-shield", false);
            for (Player player : plugin.getServer().getOnlinePlayers()) player.setShieldBlockingDelay(delayFix ? 0 : 5);
        }

        @Override
        protected void onStop() {
            for (Player player : plugin.getServer().getOnlinePlayers()) player.setShieldBlockingDelay(5);
        }

        @EventHandler
        public void onJoin(PlayerJoinEvent event) {
            if (delayFix) event.getPlayer().setShieldBlockingDelay(0);
        }

        @EventHandler(ignoreCancelled = false)
        public void onHit(EntityDamageByEntityEvent event) {
            if (!maceStun || !(event.getEntity() instanceof Player victim) || !victim.isBlocking()) return;
            if (event.getDamager() instanceof Player attacker
                    && attacker.getInventory().getItemInMainHand().getType() == Material.MACE) {
                victim.setCooldown(Material.SHIELD, 100);
                victim.clearActiveItem();
            }
        }
    }

    // ------------------------------------------------------------------------------------------

    /** Custom item cooldowns, in seconds, e.g. ENDER_PEARL: 15. */
    public static final class Cooldowns extends SimpleFeature {
        private final Map<Material, Integer> ticks = new EnumMap<>(Material.class);

        public Cooldowns(SMPKit plugin) {
            super(plugin, "cooldowns", Material.CLOCK, "Cooldowns",
                    "Custom cooldowns for pearls, apples, maces, rockets and more.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            ticks.clear();
            ConfigurationSection section = config.getConfigurationSection("items");
            if (section == null) return;
            for (String name : section.getKeys(false)) {
                Material material = Material.matchMaterial(name);
                if (material == null) {
                    plugin.getLogger().warning("cooldowns: unknown item '" + name + "'");
                    continue;
                }
                ticks.put(material, (int) Math.round(section.getDouble(name) * 20));
            }
        }

        /** Vanilla sets its own cooldown right after use, so ours is applied one tick later. */
        private void apply(Player player, Material material) {
            Integer duration = ticks.get(material);
            if (duration == null || duration <= 0) return;
            plugin.getServer().getScheduler().runTask(plugin, () -> player.setCooldown(material, duration));
        }

        @EventHandler(ignoreCancelled = true)
        public void onConsume(PlayerItemConsumeEvent event) {
            apply(event.getPlayer(), event.getItem().getType());
        }

        @EventHandler(ignoreCancelled = true)
        public void onLaunch(ProjectileLaunchEvent event) {
            Projectile projectile = event.getEntity();
            if (!(projectile.getShooter() instanceof Player player)) return;
            Material material = Material.matchMaterial(projectile.getType().name());
            if (material != null) apply(player, material);
        }

        @EventHandler(ignoreCancelled = true)
        public void onAttack(EntityDamageByEntityEvent event) {
            if (event.getDamager() instanceof Player player) {
                apply(player, player.getInventory().getItemInMainHand().getType());
            }
        }

        @EventHandler(ignoreCancelled = true)
        public void onInteract(PlayerInteractEvent event) {
            if (event.getAction().isRightClick() && event.getItem() != null
                    && event.getItem().getType() == Material.FIREWORK_ROCKET) {
                apply(event.getPlayer(), Material.FIREWORK_ROCKET);
            }
        }
    }

    // ------------------------------------------------------------------------------------------

    public static final class KillSound extends SimpleFeature {
        private String sound = "entity.player.levelup";
        private float volume = 1f, pitch = 1f;

        public KillSound(SMPKit plugin) {
            super(plugin, "kill-sound", Material.NOTE_BLOCK, "Custom Kill Sound",
                    "Plays a sound for the killer when they kill a player.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            sound = config.getString("sound", "entity.player.levelup");
            volume = (float) config.getDouble("volume", 1.0);
            pitch = (float) config.getDouble("pitch", 1.0);
        }

        @EventHandler(priority = EventPriority.MONITOR)
        public void onDeath(PlayerDeathEvent event) {
            Player killer = event.getEntity().getKiller();
            if (killer == null) return;
            try {
                killer.playSound(Sound.sound(Key.key(sound), Sound.Source.PLAYER, volume, pitch));
            } catch (Exception ex) {
                plugin.getLogger().warning("kill-sound: invalid sound '" + sound + "'");
            }
        }
    }

    // ------------------------------------------------------------------------------------------

    /** Invisible players' names are replaced in death messages ("Steve was slain by Someone"). */
    public static final class InvisQol extends SimpleFeature {
        private boolean hideDying, hideKilling;
        private String replacementName = "Someone";

        public InvisQol(SMPKit plugin) {
            super(plugin, "invis-qol", Material.GLASS_BOTTLE, "Invisibility QoL",
                    "Hide the name of invisible players in death messages.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            hideDying = config.getBoolean("hide-name-when-dying", true);
            hideKilling = config.getBoolean("hide-name-when-killing", true);
            replacementName = config.getString("replacement-name", "Someone");
        }

        /** Replaces the argument(s) that mention this player. Replacing the whole argument also removes its hover card. */
        private Component hide(Component message, String name) {
            if (!(message instanceof TranslatableComponent translatable)) return message;
            List<TranslationArgument> arguments = new ArrayList<>();
            for (TranslationArgument argument : translatable.arguments()) {
                String plain = PlainTextComponentSerializer.plainText().serialize(argument.asComponent());
                arguments.add(plain.contains(name) ? TranslationArgument.component(Component.text(replacementName)) : argument);
            }
            return translatable.arguments(arguments);
        }

        @EventHandler(priority = EventPriority.HIGH)
        public void onDeath(PlayerDeathEvent event) {
            Player victim = event.getEntity();
            Player killer = victim.getKiller();
            Component message = event.deathMessage();
            if (message == null) return;

            if (hideKilling && killer != null && killer.hasPotionEffect(PotionEffectType.INVISIBILITY)) {
                message = hide(message, killer.getName());
            }
            if (hideDying && victim.hasPotionEffect(PotionEffectType.INVISIBILITY)) {
                message = hide(message, victim.getName());
            }
            event.deathMessage(message);
        }
    }

    // ------------------------------------------------------------------------------------------

    /** Potion effects you had before popping a totem are restored afterwards. */
    public static final class TotemEffects extends SimpleFeature {
        public TotemEffects(SMPKit plugin) {
            super(plugin, "totem-effects", Material.TOTEM_OF_UNDYING, "Totem Effects",
                    "Keep your potion effects after popping a totem.");
        }

        @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
        public void onResurrect(EntityResurrectEvent event) {
            if (!(event.getEntity() instanceof Player player)) return;
            List<PotionEffect> saved = List.copyOf(player.getActivePotionEffects());
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                for (PotionEffect effect : saved) {
                    if (!player.hasPotionEffect(effect.getType())) player.addPotionEffect(effect);
                }
            });
        }
    }
}
