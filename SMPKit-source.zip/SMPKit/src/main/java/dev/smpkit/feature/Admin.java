package dev.smpkit.feature;

import dev.smpkit.SMPKit;
import dev.smpkit.Util;
import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.ItemDespawnEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.persistence.PersistentDataType;

import java.net.InetAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/** Server administration and anti-abuse features. */
public final class Admin {

    private Admin() { }

    // ------------------------------------------------------------------------------------------ chat

    public static final class ChatFilter extends SimpleFeature {
        private final Map<UUID, Long> lastMessageTime = new ConcurrentHashMap<>();
        private final Map<UUID, String> lastMessage = new ConcurrentHashMap<>();
        private final List<Pattern> blocked = new ArrayList<>();
        private String replacement = "***";
        private boolean cancelOnMatch, spamEnabled, blockDuplicates;
        private long minInterval;

        public ChatFilter(SMPKit plugin) {
            super(plugin, "chat-filter", Material.WRITABLE_BOOK, "Chat Filter & Spam Limiter",
                    "Censor bad words and stop chat spam.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            blocked.clear();
            for (String word : config.getStringList("blocked-words")) {
                blocked.add(Pattern.compile("(?i)" + Pattern.quote(word)));
            }
            replacement = config.getString("replacement", "***");
            cancelOnMatch = config.getBoolean("cancel-message", false);
            spamEnabled = config.getBoolean("spam.enabled", true);
            minInterval = config.getLong("spam.min-interval-ms", 1000);
            blockDuplicates = config.getBoolean("spam.block-duplicates", true);
        }

        @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
        public void onChat(AsyncChatEvent event) {
            Player player = event.getPlayer();
            if (player.hasPermission("smpkit.chat.bypass")) return;
            String text = PlainTextComponentSerializer.plainText().serialize(event.message());

            if (spamEnabled) {
                long now = System.currentTimeMillis();
                Long last = lastMessageTime.put(player.getUniqueId(), now);
                String previous = lastMessage.put(player.getUniqueId(), text);
                if ((last != null && now - last < minInterval) || (blockDuplicates && text.equalsIgnoreCase(previous))) {
                    event.setCancelled(true);
                    plugin.messages().send(player, "chat-spam");
                    return;
                }
            }

            String filtered = text;
            for (Pattern pattern : blocked) filtered = pattern.matcher(filtered).replaceAll(replacement);
            if (!filtered.equals(text)) {
                if (cancelOnMatch) {
                    event.setCancelled(true);
                    plugin.messages().send(player, "chat-blocked");
                } else {
                    event.message(Component.text(filtered));
                }
            }
        }
    }

    /** Re-sends chat as unsigned system messages so it can't be reported through Mojang's chat reporting. */
    public static final class NoChatReports extends SimpleFeature {
        public NoChatReports(SMPKit plugin) {
            super(plugin, "no-chat-reports", Material.WRITTEN_BOOK, "No Chat Reports",
                    "Chat is sent unsigned, so players can't be reported for it.");
        }

        @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
        public void onChat(AsyncChatEvent event) {
            event.setCancelled(true);
            Player source = event.getPlayer();
            Component name = source.displayName();
            ChatRenderer renderer = event.renderer();
            for (Audience viewer : event.viewers()) {
                viewer.sendMessage(renderer.render(source, name, event.message(), viewer));
            }
        }
    }

    public static final class BookLimit extends SimpleFeature {
        private int maxPages = 20, maxChars = 8000;

        public BookLimit(SMPKit plugin) {
            super(plugin, "book-limit", Material.BOOK, "Book Size Limit",
                    "Limit writable book size to prevent chunk bans and dupe glitches.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            maxPages = config.getInt("max-pages", 20);
            maxChars = config.getInt("max-characters", 8000);
        }

        @EventHandler(ignoreCancelled = true)
        public void onEdit(PlayerEditBookEvent event) {
            BookMeta meta = event.getNewBookMeta();
            int chars = 0;
            for (Component page : meta.pages()) chars += PlainTextComponentSerializer.plainText().serialize(page).length();
            if (meta.getPageCount() > maxPages || chars > maxChars) {
                event.setCancelled(true);
                plugin.messages().send(event.getPlayer(), "book-too-big");
            }
        }
    }

    // ------------------------------------------------------------------------------------------ clients

    public static final class ModDetector extends SimpleFeature {
        private final List<String> blocked = new ArrayList<>();
        private boolean alertNonVanilla;

        public ModDetector(SMPKit plugin) {
            super(plugin, "mod-detector", Material.SPYGLASS, "Mod Detector",
                    "Detects client brands (Fabric, Forge, hacked clients) on join.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            blocked.clear();
            for (String brand : config.getStringList("blocked-brands")) blocked.add(brand.toLowerCase(Locale.ROOT));
            alertNonVanilla = config.getBoolean("alert-non-vanilla", true);
        }

        @EventHandler
        public void onJoin(PlayerJoinEvent event) {
            Player player = event.getPlayer();
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline()) return;
                String brand = player.getClientBrandName();
                if (brand == null) return;
                String lower = brand.toLowerCase(Locale.ROOT);
                if (!player.hasPermission("smpkit.moddetector.bypass")) {
                    for (String bad : blocked) {
                        if (lower.contains(bad)) {
                            player.kick(plugin.messages().raw("mod-blocked", ph("brand", brand)));
                            return;
                        }
                    }
                }
                if (alertNonVanilla && !lower.equals("vanilla")) {
                    for (Player staff : plugin.getServer().getOnlinePlayers()) {
                        if (staff.hasPermission("smpkit.moddetector.alert")) {
                            plugin.messages().send(staff, "mod-alert", ph("player", player.getName()), ph("brand", brand));
                        }
                    }
                }
            }, 40L);
        }
    }

    /** Sends the invisible codes that well-behaved minimap mods (Xaero's etc.) use to turn themselves off. */
    public static final class AntiMinimap extends SimpleFeature {
        private List<String> codes = List.of();

        public AntiMinimap(SMPKit plugin) {
            super(plugin, "anti-minimap", Material.FILLED_MAP, "Anti Minimap",
                    "Asks minimap mods to disable themselves (only works for mods that honour it).");
        }

        @Override
        protected void load(ConfigurationSection config) {
            codes = config.getStringList("codes");
        }

        @EventHandler
        public void onJoin(PlayerJoinEvent event) {
            Player player = event.getPlayer();
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (!player.isOnline()) return;
                for (String code : codes) {
                    StringBuilder sb = new StringBuilder();
                    for (char c : code.toCharArray()) sb.append('\u00a7').append(c);
                    player.sendMessage(Component.text(sb.toString()));
                }
            }, 20L);
        }
    }

    // ------------------------------------------------------------------------------------------ login control

    public static final class Maintenance extends SimpleFeature {
        public Maintenance(SMPKit plugin) {
            super(plugin, "maintenance", Material.BARRIER, "Maintenance Mode",
                    "/maintenance on|off keeps non-staff players out.");
        }

        @Override
        public List<String> commands() { return List.of("maintenance"); }

        private boolean on() { return plugin.data().getBoolean("maintenance"); }

        @Override
        public boolean handleCommand(CommandSender sender, String command, String[] args) {
            boolean now = args.length > 0 ? args[0].equalsIgnoreCase("on") : !on();
            plugin.data().set("maintenance", now);
            plugin.messages().send(sender, now ? "maintenance-on" : "maintenance-off");
            if (now) {
                for (Player player : plugin.getServer().getOnlinePlayers()) {
                    if (!player.isOp() && !player.hasPermission("smpkit.maintenance.bypass")) {
                        player.kick(plugin.messages().raw("maintenance-kick"));
                    }
                }
            }
            return true;
        }

        @Override
        public List<String> tabComplete(CommandSender sender, String command, String[] args) {
            return args.length == 1 ? filter(List.of("on", "off"), args[0]) : List.of();
        }

        @EventHandler(priority = EventPriority.HIGH)
        public void onLogin(PlayerLoginEvent event) {
            Player player = event.getPlayer();
            if (on() && !player.isOp() && !player.hasPermission("smpkit.maintenance.bypass")) {
                event.disallow(PlayerLoginEvent.Result.KICK_OTHER, plugin.messages().raw("maintenance-kick"));
            }
        }
    }

    public static final class AntiAlt extends SimpleFeature {
        private int maxAccounts = 1;

        public AntiAlt(SMPKit plugin) {
            super(plugin, "anti-alt", Material.PLAYER_HEAD, "Anti Alt",
                    "Limits how many players may be online from one IP.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            maxAccounts = Math.max(1, config.getInt("max-accounts-per-ip", 1));
        }

        @EventHandler(priority = EventPriority.HIGH)
        public void onPreLogin(AsyncPlayerPreLoginEvent event) {
            InetAddress address = event.getAddress();
            if (address.isLoopbackAddress() || address.isSiteLocalAddress()) return;
            int count = 0;
            for (Player online : plugin.getServer().getOnlinePlayers()) {
                if (online.getUniqueId().equals(event.getUniqueId())) continue;
                if (online.getAddress() != null && address.equals(online.getAddress().getAddress())) count++;
            }
            if (count >= maxAccounts) {
                event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, plugin.messages().raw("alt-blocked"));
            }
        }
    }

    /** Looks IPs up on ip-api.com (free, HTTP only). Fails open if the lookup fails. */
    public static final class AntiVpn extends SimpleFeature {
        private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).build();
        private final Map<String, Boolean> cache = new ConcurrentHashMap<>();
        private boolean blockHosting;

        public AntiVpn(SMPKit plugin) {
            super(plugin, "anti-vpn", Material.COMPASS, "Anti VPN",
                    "Blocks proxies / VPNs (uses the ip-api.com lookup service).");
        }

        @Override
        protected void load(ConfigurationSection config) {
            blockHosting = config.getBoolean("block-hosting-ips", true);
        }

        private boolean lookup(String ip) {
            try {
                HttpRequest request = HttpRequest.newBuilder(URI.create("http://ip-api.com/json/" + ip + "?fields=status,proxy,hosting"))
                        .timeout(Duration.ofSeconds(3)).GET().build();
                String body = client.send(request, HttpResponse.BodyHandlers.ofString()).body();
                return body.contains("\"proxy\":true") || (blockHosting && body.contains("\"hosting\":true"));
            } catch (Exception ex) {
                return false;
            }
        }

        @EventHandler(priority = EventPriority.HIGH)
        public void onPreLogin(AsyncPlayerPreLoginEvent event) {
            InetAddress address = event.getAddress();
            if (address.isLoopbackAddress() || address.isSiteLocalAddress() || address.isAnyLocalAddress()) return;
            String ip = address.getHostAddress();
            Boolean bad = cache.get(ip);
            if (bad == null) {
                bad = lookup(ip);
                cache.put(ip, bad);
            }
            if (bad) event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, plugin.messages().raw("vpn-blocked"));
        }
    }

    // ------------------------------------------------------------------------------------------ death handling

    /** Dying bans you for a while (or forever). /revive <name> lifts it. */
    public static final class DeathBan extends SimpleFeature {
        private final Map<UUID, Long> until = new ConcurrentHashMap<>();
        private long durationMillis;

        public DeathBan(SMPKit plugin) {
            super(plugin, "death-ban", Material.SKELETON_SKULL, "Death Ban",
                    "Players are banned for a while after dying. Use /revive to unban.");
        }

        @Override
        public List<String> commands() { return List.of("revive"); }

        @Override
        protected void load(ConfigurationSection config) {
            long minutes = config.getLong("duration-minutes", 60);
            durationMillis = minutes <= 0 ? -1 : minutes * 60_000L;
        }

        @Override
        protected void onStart() {
            until.clear();
            for (String id : plugin.data().keys("deathban")) {
                try {
                    until.put(UUID.fromString(id), plugin.data().getLong("deathban." + id + ".until", 0));
                } catch (IllegalArgumentException ignored) { }
            }
        }

        @Override
        public boolean handleCommand(CommandSender sender, String command, String[] args) {
            if (args.length < 1) {
                plugin.messages().send(sender, "usage-revive");
                return true;
            }
            for (String id : plugin.data().keys("deathban")) {
                String name = plugin.data().getString("deathban." + id + ".name");
                if (name != null && name.equalsIgnoreCase(args[0])) {
                    plugin.data().set("deathban." + id, null);
                    until.remove(UUID.fromString(id));
                    plugin.messages().send(sender, "revive-done", ph("player", name));
                    return true;
                }
            }
            plugin.messages().send(sender, "revive-none");
            return true;
        }

        @Override
        public List<String> tabComplete(CommandSender sender, String command, String[] args) {
            if (args.length != 1) return List.of();
            List<String> names = new ArrayList<>();
            for (String id : plugin.data().keys("deathban")) {
                String name = plugin.data().getString("deathban." + id + ".name");
                if (name != null) names.add(name);
            }
            return filter(names, args[0]);
        }

        private Component timeLeft(long expires) {
            return plugin.messages().raw("deathban-kick",
                    ph("time", expires == Long.MAX_VALUE ? "forever" : Util.duration(expires - System.currentTimeMillis())));
        }

        @EventHandler(priority = EventPriority.MONITOR)
        public void onDeath(PlayerDeathEvent event) {
            Player player = event.getEntity();
            if (player.hasPermission("smpkit.deathban.bypass")) return;
            long expires = durationMillis < 0 ? Long.MAX_VALUE : System.currentTimeMillis() + durationMillis;
            until.put(player.getUniqueId(), expires);
            String path = "deathban." + player.getUniqueId();
            plugin.data().set(path + ".until", expires);
            plugin.data().set(path + ".name", player.getName());
            plugin.getServer().getScheduler().runTask(plugin, () -> player.kick(timeLeft(expires)));
        }

        @EventHandler(priority = EventPriority.HIGH)
        public void onPreLogin(AsyncPlayerPreLoginEvent event) {
            Long expires = until.get(event.getUniqueId());
            if (expires == null) return;
            if (expires != Long.MAX_VALUE && expires <= System.currentTimeMillis()) {
                until.remove(event.getUniqueId());
                return;
            }
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED, timeLeft(expires));
        }
    }

    /** Items dropped on death can't be destroyed. */
    public static final class DeathDrops extends SimpleFeature {
        private record Death(Location location, int tick) { }

        private final List<Death> recent = new ArrayList<>();
        private final NamespacedKey key;

        public DeathDrops(SMPKit plugin) {
            super(plugin, "immortal-death-drops", Material.BEDROCK, "Immortal Death Drops",
                    "Items dropped on death can't burn, explode or despawn.");
            this.key = new NamespacedKey(plugin, "immortal_drop");
        }

        @Override
        protected void onStop() {
            recent.clear();
        }

        @EventHandler(priority = EventPriority.MONITOR)
        public void onDeath(PlayerDeathEvent event) {
            recent.add(new Death(event.getEntity().getLocation(), plugin.getServer().getCurrentTick()));
        }

        @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
        public void onSpawn(ItemSpawnEvent event) {
            int now = plugin.getServer().getCurrentTick();
            recent.removeIf(death -> now - death.tick() > 2);
            Item item = event.getEntity();
            for (Death death : recent) {
                if (death.location().getWorld() == item.getWorld() && death.location().distanceSquared(item.getLocation()) <= 16) {
                    item.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
                    return;
                }
            }
        }

        private boolean marked(Entity entity) {
            return entity instanceof Item item && item.getPersistentDataContainer().has(key, PersistentDataType.BYTE);
        }

        @EventHandler(ignoreCancelled = true)
        public void onDamage(EntityDamageEvent event) {
            if (marked(event.getEntity()) && event.getCause() != EntityDamageEvent.DamageCause.VOID) event.setCancelled(true);
        }

        @EventHandler(ignoreCancelled = true)
        public void onDespawn(ItemDespawnEvent event) {
            if (marked(event.getEntity())) event.setCancelled(true);
        }
    }
}
