package dev.smpkit.feature;

import dev.smpkit.Messages;
import dev.smpkit.SMPKit;
import dev.smpkit.Util;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.entity.minecart.ExplosiveMinecart;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BrewEvent;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** "Ban X" features. */
public final class Bans {

    private Bans() { }

    // ------------------------------------------------------------------------------------------ items

    /** Shared logic: blocks crafting, smithing, use, attacking, pickup and equipping of banned items. */
    public abstract static class AbstractItemBan extends SimpleFeature {

        protected AbstractItemBan(SMPKit plugin, String key, Material icon, String title, String description) {
            super(plugin, key, icon, title, description);
        }

        protected abstract boolean banned(Material material);

        private boolean banned(ItemStack stack) {
            return stack != null && !stack.getType().isAir() && banned(stack.getType());
        }

        private void tell(Player player, ItemStack stack) {
            plugin.messages().send(player, "item-banned", ph("item", Messages.pretty(stack.getType())));
        }

        @EventHandler
        public void onPrepareCraft(PrepareItemCraftEvent event) {
            if (banned(event.getInventory().getResult())) event.getInventory().setResult(null);
        }

        @EventHandler
        public void onPrepareSmith(PrepareSmithingEvent event) {
            if (banned(event.getResult())) event.setResult(null);
        }

        @EventHandler(ignoreCancelled = true)
        public void onInteract(PlayerInteractEvent event) {
            if (!event.getAction().isRightClick()) return;
            ItemStack item = event.getItem();
            if (banned(item) && !event.getPlayer().hasPermission("smpkit.itemban.bypass")) {
                event.setCancelled(true);
                tell(event.getPlayer(), item);
            }
        }

        @EventHandler(ignoreCancelled = true)
        public void onAttack(EntityDamageByEntityEvent event) {
            if (event.getDamager() instanceof Player player && !player.hasPermission("smpkit.itemban.bypass")) {
                ItemStack hand = player.getInventory().getItemInMainHand();
                if (banned(hand)) {
                    event.setCancelled(true);
                    tell(player, hand);
                }
            }
        }

        @EventHandler(ignoreCancelled = true)
        public void onPickup(EntityPickupItemEvent event) {
            if (event.getEntity() instanceof Player player && !player.hasPermission("smpkit.itemban.bypass")
                    && banned(event.getItem().getItemStack())) {
                event.setCancelled(true);
            }
        }

        @EventHandler(ignoreCancelled = true)
        public void onClick(InventoryClickEvent event) {
            if (!(event.getWhoClicked() instanceof Player player) || player.hasPermission("smpkit.itemban.bypass")) return;
            boolean intoArmor = event.getSlotType() == InventoryType.SlotType.ARMOR && banned(player.getItemOnCursor());
            boolean shiftEquip = event.isShiftClick() && banned(event.getCurrentItem());
            if (intoArmor || shiftEquip) event.setCancelled(true);
        }
    }

    /** Configurable list of banned items (supports NETHERITE_* wildcards). */
    public static final class ItemBan extends AbstractItemBan {
        private Set<Material> set = Set.of();

        public ItemBan(SMPKit plugin) {
            super(plugin, "item-ban", Material.STRUCTURE_VOID, "Item Ban", "Ban any items by listing them in the config.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            set = Util.materials(config.getStringList("materials"), plugin.getLogger(), "item-ban");
        }

        @Override
        protected boolean banned(Material material) { return set.contains(material); }
    }

    /** Netherite tools, weapons and armor. */
    public static final class NetheriteBan extends AbstractItemBan {
        private static final String[] SUFFIXES = {"_HELMET", "_CHESTPLATE", "_LEGGINGS", "_BOOTS", "_SWORD",
                "_PICKAXE", "_AXE", "_SHOVEL", "_HOE", "_SPEAR"};

        public NetheriteBan(SMPKit plugin) {
            super(plugin, "ban-netherite", Material.NETHERITE_INGOT, "Ban Netherite",
                    "Netherite tools, weapons and armor can't be crafted or used.");
        }

        @Override
        protected boolean banned(Material material) {
            String name = material.name();
            if (!name.startsWith("NETHERITE_")) return false;
            for (String suffix : SUFFIXES) if (name.endsWith(suffix)) return true;
            return false;
        }
    }

    // ------------------------------------------------------------------------------------------ explosives

    public static final class Explosives extends SimpleFeature {
        private boolean tnt, minecart, crystal, anchor, beds;

        public Explosives(SMPKit plugin) {
            super(plugin, "ban-explosives", Material.TNT, "Ban Explosives",
                    "Disable TNT, TNT minecarts, end crystals, anchors and bed explosions.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            tnt = config.getBoolean("tnt", true);
            minecart = config.getBoolean("tnt-minecart", true);
            crystal = config.getBoolean("end-crystal", true);
            anchor = config.getBoolean("respawn-anchor", true);
            beds = config.getBoolean("beds", true);
        }

        @EventHandler(ignoreCancelled = true)
        public void onPlace(BlockPlaceEvent event) {
            if (tnt && event.getBlockPlaced().getType() == Material.TNT) {
                event.setCancelled(true);
                plugin.messages().send(event.getPlayer(), "action-disabled");
            }
        }

        @EventHandler(ignoreCancelled = true)
        public void onInteract(PlayerInteractEvent event) {
            if (!event.getAction().isRightClick()) return;
            Player player = event.getPlayer();
            ItemStack item = event.getItem();
            if (item != null && ((crystal && item.getType() == Material.END_CRYSTAL)
                    || (minecart && item.getType() == Material.TNT_MINECART))) {
                event.setCancelled(true);
                plugin.messages().send(player, "action-disabled");
                return;
            }
            Block block = event.getClickedBlock();
            if (block == null) return;
            World.Environment env = block.getWorld().getEnvironment();
            if (anchor && block.getType() == Material.RESPAWN_ANCHOR && env != World.Environment.NETHER) {
                event.setCancelled(true);
                plugin.messages().send(player, "action-disabled");
            } else if (beds && Tag.BEDS.isTagged(block.getType()) && env != World.Environment.NORMAL) {
                event.setCancelled(true);
                plugin.messages().send(player, "action-disabled");
            }
        }

        private boolean isBannedSource(Entity entity) {
            return (tnt && entity instanceof TNTPrimed)
                    || (minecart && entity instanceof ExplosiveMinecart)
                    || (crystal && entity instanceof EnderCrystal);
        }

        @EventHandler(ignoreCancelled = true)
        public void onExplode(EntityExplodeEvent event) {
            if (isBannedSource(event.getEntity())) {
                event.setCancelled(true);
                event.blockList().clear();
            }
        }

        @EventHandler(ignoreCancelled = true)
        public void onBlockExplode(BlockExplodeEvent event) {
            if (anchor || beds) {
                event.setCancelled(true);
                event.blockList().clear();
            }
        }

        /** Insurance: no damage from the banned sources even if an explosion slips through. */
        @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
        public void onDamage(EntityDamageEvent event) {
            if (event.getCause() == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION && (anchor || beds)) {
                event.setCancelled(true);
            } else if (event.getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION
                    && event instanceof EntityDamageByEntityEvent byEntity && isBannedSource(byEntity.getDamager())) {
                event.setCancelled(true);
            }
        }
    }

    // ------------------------------------------------------------------------------------------ misc bans

    public static final class Draining extends SimpleFeature {
        public Draining(SMPKit plugin) {
            super(plugin, "ban-draining", Material.BUCKET, "Ban Draining",
                    "Water and lava can't be picked up with buckets.");
        }

        @EventHandler(ignoreCancelled = true)
        public void onFill(PlayerBucketFillEvent event) {
            Material type = event.getBlock().getType();
            if ((type == Material.WATER || type == Material.LAVA) && !event.getPlayer().hasPermission("smpkit.draining.bypass")) {
                event.setCancelled(true);
                plugin.messages().send(event.getPlayer(), "action-disabled");
            }
        }
    }

    public static final class TippedArrows extends SimpleFeature {
        public TippedArrows(SMPKit plugin) {
            super(plugin, "ban-tipped-arrows", Material.TIPPED_ARROW, "Ban Tipped Arrows",
                    "Tipped arrows can't be crafted or shot.");
        }

        @EventHandler
        public void onPrepare(PrepareItemCraftEvent event) {
            ItemStack result = event.getInventory().getResult();
            if (result != null && result.getType() == Material.TIPPED_ARROW) event.getInventory().setResult(null);
        }

        @EventHandler(ignoreCancelled = true)
        public void onShoot(EntityShootBowEvent event) {
            ItemStack ammo = event.getConsumable();
            if (ammo != null && ammo.getType() == Material.TIPPED_ARROW) {
                event.setCancelled(true);
                if (event.getEntity() instanceof Player player) plugin.messages().send(player, "action-disabled");
            }
        }
    }

    public static final class DisableVaults extends SimpleFeature {
        public DisableVaults(SMPKit plugin) {
            super(plugin, "disable-vaults", Material.VAULT, "Disable Vaults", "Trial vaults can't be opened.");
        }

        @EventHandler(ignoreCancelled = true)
        public void onInteract(PlayerInteractEvent event) {
            Block block = event.getClickedBlock();
            if (event.getAction() == Action.RIGHT_CLICK_BLOCK && block != null && block.getType() == Material.VAULT) {
                event.setCancelled(true);
                plugin.messages().send(event.getPlayer(), "action-disabled");
            }
        }
    }

    public static final class DimensionBan extends SimpleFeature {
        private boolean banNether, banEnd;

        public DimensionBan(SMPKit plugin) {
            super(plugin, "dimension-ban", Material.END_PORTAL_FRAME, "Dimension Ban",
                    "Block entry to the Nether and/or the End.");
        }

        @Override
        protected void load(ConfigurationSection config) {
            banNether = config.getBoolean("ban-nether", false);
            banEnd = config.getBoolean("ban-end", true);
        }

        @EventHandler(ignoreCancelled = true)
        public void onPortal(PlayerPortalEvent event) {
            Player player = event.getPlayer();
            if (player.hasPermission("smpkit.dimensionban.bypass")) return;
            if (event.getFrom().getWorld().getEnvironment() != World.Environment.NORMAL) return; // only entering
            PlayerTeleportEvent.TeleportCause cause = event.getCause();
            if ((banNether && cause == PlayerTeleportEvent.TeleportCause.NETHER_PORTAL)
                    || (banEnd && cause == PlayerTeleportEvent.TeleportCause.END_PORTAL)) {
                event.setCancelled(true);
                plugin.messages().send(player, "dimension-banned");
            }
        }
    }

    // ------------------------------------------------------------------------------------------ enchants

    public static final class EnchantBan extends SimpleFeature {
        private final Set<Enchantment> banned = new HashSet<>();
        private final Map<Enchantment, Integer> maxLevels = new HashMap<>();

        public EnchantBan(SMPKit plugin) {
            super(plugin, "enchant-ban", Material.ENCHANTED_BOOK, "Enchant Ban",
                    "Ban enchantments or cap their level.");
        }

        private Enchantment lookup(String name) {
            return Registry.ENCHANTMENT.get(NamespacedKey.minecraft(name.trim().toLowerCase(Locale.ROOT)));
        }

        @Override
        protected void load(ConfigurationSection config) {
            banned.clear();
            maxLevels.clear();
            for (String name : config.getStringList("banned")) {
                Enchantment enchantment = lookup(name);
                if (enchantment == null) plugin.getLogger().warning("enchant-ban: unknown enchantment '" + name + "'");
                else banned.add(enchantment);
            }
            ConfigurationSection max = config.getConfigurationSection("max-levels");
            if (max != null) {
                for (String name : max.getKeys(false)) {
                    Enchantment enchantment = lookup(name);
                    if (enchantment != null) maxLevels.put(enchantment, max.getInt(name));
                }
            }
        }

        private boolean sanitize(ItemStack stack) {
            boolean changed = false;
            if (stack.getItemMeta() instanceof EnchantmentStorageMeta storage) {
                for (Map.Entry<Enchantment, Integer> entry : new HashMap<>(storage.getStoredEnchants()).entrySet()) {
                    Enchantment enchantment = entry.getKey();
                    if (banned.contains(enchantment)) {
                        storage.removeStoredEnchant(enchantment);
                        changed = true;
                    } else if (maxLevels.containsKey(enchantment) && entry.getValue() > maxLevels.get(enchantment)) {
                        storage.addStoredEnchant(enchantment, maxLevels.get(enchantment), true);
                        changed = true;
                    }
                }
                if (changed) stack.setItemMeta(storage);
                return changed;
            }
            for (Map.Entry<Enchantment, Integer> entry : new HashMap<>(stack.getEnchantments()).entrySet()) {
                Enchantment enchantment = entry.getKey();
                if (banned.contains(enchantment)) {
                    stack.removeEnchantment(enchantment);
                    changed = true;
                } else if (maxLevels.containsKey(enchantment) && entry.getValue() > maxLevels.get(enchantment)) {
                    stack.addUnsafeEnchantment(enchantment, maxLevels.get(enchantment));
                    changed = true;
                }
            }
            return changed;
        }

        @EventHandler
        public void onEnchant(EnchantItemEvent event) {
            Map<Enchantment, Integer> toAdd = event.getEnchantsToAdd();
            for (Enchantment enchantment : new HashSet<>(toAdd.keySet())) {
                if (banned.contains(enchantment)) toAdd.remove(enchantment);
                else if (maxLevels.containsKey(enchantment) && toAdd.get(enchantment) > maxLevels.get(enchantment)) {
                    toAdd.put(enchantment, maxLevels.get(enchantment));
                }
            }
        }

        @EventHandler(priority = EventPriority.HIGH)
        public void onAnvil(PrepareAnvilEvent event) {
            ItemStack result = event.getResult();
            if (result == null || result.getType().isAir()) return;
            ItemStack copy = result.clone();
            if (sanitize(copy)) event.setResult(copy);
        }
    }

    // ------------------------------------------------------------------------------------------ potions

    public static final class PotionBan extends SimpleFeature {
        private final Set<String> banned = new HashSet<>();

        public PotionBan(SMPKit plugin) {
            super(plugin, "potion-ban", Material.SPLASH_POTION, "Potion Ban",
                    "Ban potion types (e.g. STRONG_STRENGTH, or STRENGTH for all tiers).");
        }

        @Override
        protected void load(ConfigurationSection config) {
            banned.clear();
            for (String name : config.getStringList("banned")) banned.add(name.trim().toUpperCase(Locale.ROOT));
        }

        private boolean isBanned(ItemStack stack) {
            if (stack == null || !(stack.getItemMeta() instanceof PotionMeta meta)) return false;
            PotionType type = meta.getBasePotionType();
            if (type == null) return false;
            String full = type.getKey().getKey().toUpperCase(Locale.ROOT);
            String base = full.replaceFirst("^(LONG_|STRONG_)", "");
            return banned.contains(full) || banned.contains(base);
        }

        @EventHandler(ignoreCancelled = true)
        public void onDrink(PlayerItemConsumeEvent event) {
            if (isBanned(event.getItem())) {
                event.setCancelled(true);
                plugin.messages().send(event.getPlayer(), "potion-banned");
            }
        }

        @EventHandler(ignoreCancelled = true)
        public void onThrow(ProjectileLaunchEvent event) {
            if (event.getEntity() instanceof ThrownPotion potion && isBanned(potion.getItem())) {
                event.setCancelled(true);
                if (potion.getShooter() instanceof Player player) plugin.messages().send(player, "potion-banned");
            }
        }

        @EventHandler(ignoreCancelled = true)
        public void onBrew(BrewEvent event) {
            for (ItemStack result : event.getResults()) {
                if (isBanned(result)) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
    }
}
