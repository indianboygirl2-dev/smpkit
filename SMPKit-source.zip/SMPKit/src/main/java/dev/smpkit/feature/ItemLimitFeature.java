package dev.smpkit.feature;

import dev.smpkit.Messages;
import dev.smpkit.SMPKit;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.CrafterCraftEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ItemStack;

import java.util.EnumMap;
import java.util.Map;

/**
 * Server-wide craft limits (e.g. only one Mace ever).
 * Also guards against the shift-click / spam-craft duplication trick.
 */
public final class ItemLimitFeature extends Feature {

    private final Map<Material, Integer> limits = new EnumMap<>(Material.class);

    public ItemLimitFeature(SMPKit plugin) {
        super(plugin);
    }

    @Override
    public String key() { return "item-limits"; }

    @Override public org.bukkit.Material icon() { return org.bukkit.Material.BARRIER; }
    @Override public String title() { return "Craft Limit"; }
    @Override public String description() { return "Server-wide craft limits, e.g. only one Mace."; }

    @Override
    protected void load(ConfigurationSection config) {
        limits.clear();
        ConfigurationSection section = config.getConfigurationSection("limits");
        if (section == null) return;
        for (String name : section.getKeys(false)) {
            Material material = Material.matchMaterial(name);
            if (material == null) {
                plugin.getLogger().warning("item-limits: unknown material '" + name + "'");
                continue;
            }
            limits.put(material, section.getInt(name));
        }
    }

    public Map<Material, Integer> limits() { return limits; }

    public int crafted(Material material) {
        return plugin.data().getInt("crafted." + material.name());
    }

    public void reset(Material material) {
        plugin.data().set("crafted." + material.name(), null);
    }

    public boolean reached(Material material) {
        Integer limit = limits.get(material);
        return limit != null && crafted(material) >= limit;
    }

    public void record(Material material, int amount) {
        plugin.data().set("crafted." + material.name(), crafted(material) + amount);
    }

    /** Hide the result in the grid once the limit is hit. */
    @EventHandler
    public void onPrepare(PrepareItemCraftEvent event) {
        ItemStack result = event.getInventory().getResult();
        if (result != null && reached(result.getType())) {
            event.getInventory().setResult(null);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        Material type = event.getRecipe().getResult().getType();
        if (!limits.containsKey(type)) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;

        if (reached(type)) {
            event.setCancelled(true);
            plugin.messages().send(player, "item-limit-reached", Placeholder.unparsed("item", Messages.pretty(type)));
            return;
        }
        // Shift-click and non-empty cursor are where the "spam craft" duplication comes from.
        if (event.isShiftClick() || !player.getItemOnCursor().getType().isAir()) {
            event.setCancelled(true);
            plugin.messages().send(player, "item-limit-shift");
            return;
        }
        record(type, event.getRecipe().getResult().getAmount());
    }

    /** Auto-crafters must obey limits too. */
    @EventHandler(ignoreCancelled = true)
    public void onCrafter(CrafterCraftEvent event) {
        Material type = event.getResult().getType();
        if (!limits.containsKey(type)) return;
        if (reached(type)) {
            event.setCancelled(true);
            return;
        }
        record(type, event.getResult().getAmount());
    }
}
