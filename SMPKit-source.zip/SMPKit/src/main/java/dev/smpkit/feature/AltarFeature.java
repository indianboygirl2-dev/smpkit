package dev.smpkit.feature;

import dev.smpkit.ItemParser;
import dev.smpkit.Messages;
import dev.smpkit.SMPKit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Altars and rituals. Staff mark blocks as altars with /altar create. Players drop the ingredients
 * on top of an altar and right-click it with an empty hand to perform a ritual.
 */
public final class AltarFeature extends Feature {

    private record Ritual(String id, ItemStack result, Map<Material, Integer> ingredients) { }

    private final Map<String, Ritual> rituals = new LinkedHashMap<>();
    private double radius = 1.5;

    public AltarFeature(SMPKit plugin) {
        super(plugin);
    }

    @Override public String key() { return "altars"; }
    @Override public Material icon() { return Material.CRYING_OBSIDIAN; }
    @Override public String title() { return "Altars & Rituals"; }
    @Override public String description() { return "Drop items on an altar and right-click to craft custom items."; }
    @Override public List<String> commands() { return List.of("altar", "ritual"); }

    @Override
    protected void load(ConfigurationSection config) {
        radius = config.getDouble("scan-radius", 1.5);
        rituals.clear();
        ConfigurationSection section = config.getConfigurationSection("rituals");
        if (section == null) return;
        for (String id : section.getKeys(false)) {
            ItemStack result = ItemParser.parse(plugin, section.getString(id + ".result", ""), "ritual " + id);
            if (result == null) continue;
            Map<Material, Integer> ingredients = new EnumMap<>(Material.class);
            for (String line : section.getStringList(id + ".ingredients")) {
                String[] parts = line.split(":");
                Material material = Material.matchMaterial(parts[0].trim());
                if (material == null) {
                    plugin.getLogger().warning("ritual " + id + ": unknown ingredient '" + parts[0] + "'");
                    continue;
                }
                int amount = 1;
                try {
                    if (parts.length > 1) amount = Integer.parseInt(parts[1].trim());
                } catch (NumberFormatException ignored) { }
                ingredients.merge(material, Math.max(1, amount), Integer::sum);
            }
            if (!ingredients.isEmpty()) rituals.put(id, new Ritual(id, result, ingredients));
        }
    }

    // ------------------------------------------------------------------------------------------ altar storage

    private String altarAt(Block block) {
        for (String name : plugin.data().keys("altars")) {
            Location loc = plugin.data().getLocation("altars." + name);
            if (loc != null && loc.getWorld() == block.getWorld()
                    && loc.getBlockX() == block.getX() && loc.getBlockY() == block.getY() && loc.getBlockZ() == block.getZ()) {
                return name;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------------------------------ commands

    @Override
    public boolean handleCommand(CommandSender sender, String command, String[] args) {
        if (command.equals("ritual")) {
            sender.sendMessage(plugin.messages().prefixed("ritual-header"));
            for (Ritual ritual : rituals.values()) {
                StringBuilder needs = new StringBuilder();
                for (Map.Entry<Material, Integer> entry : ritual.ingredients().entrySet()) {
                    if (needs.length() > 0) needs.append(", ");
                    needs.append(entry.getValue()).append("x ").append(Messages.pretty(entry.getKey()));
                }
                sender.sendMessage(plugin.messages().raw("ritual-line",
                        ph("result", Messages.pretty(ritual.result().getType())), ph("needs", needs)));
            }
            return true;
        }

        if (args.length == 0) {
            plugin.messages().send(sender, "usage-altar");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                Player player = playerOnly(sender);
                if (player == null) return true;
                if (args.length < 2) {
                    plugin.messages().send(sender, "usage-altar");
                    return true;
                }
                Block target = player.getTargetBlockExact(6);
                if (target == null) {
                    plugin.messages().send(sender, "altar-look");
                } else if (plugin.data().contains("altars." + args[1])) {
                    plugin.messages().send(sender, "altar-exists");
                } else {
                    plugin.data().set("altars." + args[1], target.getLocation());
                    plugin.messages().send(sender, "altar-created", ph("name", args[1]));
                }
            }
            case "remove" -> {
                if (args.length < 2 || !plugin.data().contains("altars." + args[1])) {
                    plugin.messages().send(sender, "altar-missing");
                } else {
                    plugin.data().set("altars." + args[1], null);
                    plugin.messages().send(sender, "altar-removed", ph("name", args[1]));
                }
            }
            case "list" -> plugin.messages().send(sender, "altar-list", ph("altars", String.join(", ", plugin.data().keys("altars"))));
            default -> plugin.messages().send(sender, "usage-altar");
        }
        return true;
    }

    @Override
    public List<String> tabComplete(CommandSender sender, String command, String[] args) {
        if (!command.equals("altar")) return List.of();
        if (args.length == 1) return filter(List.of("create", "remove", "list"), args[0]);
        if (args.length == 2 && args[0].equalsIgnoreCase("remove")) return filter(plugin.data().keys("altars"), args[1]);
        return List.of();
    }

    // ------------------------------------------------------------------------------------------ interaction

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (altarAt(event.getBlock()) != null && !event.getPlayer().hasPermission("smpkit.altar")) {
            event.setCancelled(true);
            plugin.messages().send(event.getPlayer(), "altar-protected");
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND || event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        Player player = event.getPlayer();
        if (block == null || !player.getInventory().getItemInMainHand().getType().isAir()) return;
        if (altarAt(block) == null) return;

        event.setCancelled(true);
        perform(player, block);
    }

    private void perform(Player player, Block altar) {
        Location center = altar.getLocation().add(0.5, 1.0, 0.5);
        List<Item> items = new ArrayList<>();
        for (Entity entity : altar.getWorld().getNearbyEntities(center, radius, radius, radius, e -> e instanceof Item)) {
            items.add((Item) entity);
        }
        Map<Material, Integer> have = new EnumMap<>(Material.class);
        for (Item item : items) have.merge(item.getItemStack().getType(), item.getItemStack().getAmount(), Integer::sum);

        Ritual match = null;
        for (Ritual ritual : rituals.values()) {
            boolean ok = true;
            for (Map.Entry<Material, Integer> need : ritual.ingredients().entrySet()) {
                if (have.getOrDefault(need.getKey(), 0) < need.getValue()) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                match = ritual;
                break;
            }
        }
        if (match == null) {
            plugin.messages().send(player, "ritual-nothing");
            return;
        }

        // Rituals respect craft limits (e.g. one Mace ever).
        ItemLimitFeature limits = plugin.itemLimits();
        Material type = match.result().getType();
        if (limits.isRunning() && limits.limits().containsKey(type)) {
            if (limits.reached(type)) {
                plugin.messages().send(player, "ritual-limit", ph("item", Messages.pretty(type)));
                return;
            }
            limits.record(type, match.result().getAmount());
        }

        for (Map.Entry<Material, Integer> need : match.ingredients().entrySet()) {
            int remaining = need.getValue();
            for (Item item : items) {
                if (remaining <= 0) break;
                ItemStack stack = item.getItemStack();
                if (stack.getType() != need.getKey()) continue;
                int take = Math.min(remaining, stack.getAmount());
                remaining -= take;
                if (take >= stack.getAmount()) {
                    item.remove();
                } else {
                    stack.setAmount(stack.getAmount() - take);
                    item.setItemStack(stack);
                }
            }
        }

        altar.getWorld().strikeLightningEffect(center);
        altar.getWorld().spawnParticle(Particle.END_ROD, center, 40, 0.4, 0.6, 0.4, 0.05);
        altar.getWorld().playSound(center, Sound.BLOCK_BEACON_ACTIVATE, 1f, 1f);
        Item dropped = altar.getWorld().dropItem(center.clone().add(0, 0.5, 0), match.result().clone());
        dropped.setVelocity(new org.bukkit.util.Vector(0, 0.2, 0));
        plugin.messages().send(player, "ritual-complete", ph("item", Messages.pretty(type)));
    }
}
