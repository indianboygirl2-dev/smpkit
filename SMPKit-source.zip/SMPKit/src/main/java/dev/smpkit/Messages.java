package dev.smpkit;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.Locale;

/** Loads messages from config.yml and renders them with MiniMessage. */
public final class Messages {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private ConfigurationSection section;
    private String prefix = "";

    public void reload(FileConfiguration config) {
        this.section = config.getConfigurationSection("messages");
        this.prefix = config.getString("messages.prefix", "");
    }

    /** Message without the prefix (action bars, broadcasts, titles). */
    public Component raw(String key, TagResolver... resolvers) {
        return MM.deserialize(text(key), resolvers);
    }

    /** Message with the prefix. */
    public Component prefixed(String key, TagResolver... resolvers) {
        return MM.deserialize(prefix + text(key), resolvers);
    }

    public void send(CommandSender to, String key, TagResolver... resolvers) {
        to.sendMessage(prefixed(key, resolvers));
    }

    private String text(String key) {
        return section == null ? key : section.getString(key, key);
    }

    /** DIAMOND_SWORD -> "Diamond Sword" */
    public static String pretty(Material material) {
        StringBuilder sb = new StringBuilder();
        for (String word : material.name().toLowerCase(Locale.ROOT).split("_")) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return sb.toString();
    }
}
