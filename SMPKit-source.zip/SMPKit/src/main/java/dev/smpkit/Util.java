package dev.smpkit;

import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Collection;
import java.util.EnumSet;
import java.util.Locale;
import java.util.Set;
import java.util.logging.Logger;

public final class Util {

    private Util() { }

    /** The player responsible for this damage (melee or projectile), or null. */
    public static Player attacker(EntityDamageEvent event) {
        if (!(event instanceof EntityDamageByEntityEvent byEntity)) return null;
        Entity damager = byEntity.getDamager();
        if (damager instanceof Player player) return player;
        if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Player shooter) return shooter;
        return null;
    }

    public static boolean hasArmor(Player player) {
        for (ItemStack piece : player.getInventory().getArmorContents()) {
            if (piece != null && !piece.getType().isAir()) return true;
        }
        return false;
    }

    /** Parses material names; an entry ending in * is a prefix wildcard (NETHERITE_*). */
    public static Set<Material> materials(Collection<String> names, Logger log, String context) {
        Set<Material> result = EnumSet.noneOf(Material.class);
        for (String entry : names) {
            String name = entry.trim().toUpperCase(Locale.ROOT);
            if (name.endsWith("*")) {
                String prefix = name.substring(0, name.length() - 1);
                for (Material material : Material.values()) {
                    if (!material.isLegacy() && material.isItem() && material.name().startsWith(prefix)) result.add(material);
                }
            } else {
                Material material = Material.matchMaterial(name);
                if (material == null) log.warning(context + ": unknown material '" + entry + "'");
                else result.add(material);
            }
        }
        return result;
    }

    public static String duration(long millis) {
        long s = Math.max(0, millis / 1000);
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        if (h > 0) return h + "h " + m + "m";
        if (m > 0) return m + "m " + sec + "s";
        return sec + "s";
    }

    /** Teleport after a delay; cancelled if the player moves. */
    public static void teleport(SMPKit plugin, Player player, Location destination, int delaySeconds) {
        if (delaySeconds <= 0 || player.hasPermission("smpkit.teleport.bypass")) {
            player.teleport(destination);
            return;
        }
        Location start = player.getLocation();
        plugin.messages().send(player, "teleport-wait", Placeholder.unparsed("seconds", String.valueOf(delaySeconds)));
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            Location now = player.getLocation();
            if (now.getWorld() != start.getWorld() || now.distanceSquared(start) > 1.5) {
                plugin.messages().send(player, "teleport-cancelled");
                return;
            }
            player.teleport(destination);
        }, delaySeconds * 20L);
    }
}
