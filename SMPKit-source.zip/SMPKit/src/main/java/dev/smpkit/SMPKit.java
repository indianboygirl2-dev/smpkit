package dev.smpkit;

import dev.smpkit.feature.*;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class SMPKit extends JavaPlugin {

    private final Messages messages = new Messages();
    private final List<Feature> features = new ArrayList<>();
    private DataStore data;
    private ItemLimitFeature itemLimits;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        data = new DataStore(this);

        itemLimits = new ItemLimitFeature(this);
        features.add(itemLimits);
        features.add(new JoinKitFeature(this));
        features.add(new CombatFeature(this));
        features.add(new ImmortalItemsFeature(this));
        features.add(new DamageCapFeature(this));
        features.add(new VanishFeature(this));
        features.add(new InvseeFeature(this));
        features.add(new FreezeFeature(this));

        // protection
        features.add(new Protection.Naked(this));
        features.add(new Protection.Afk(this));
        features.add(new Protection.VoidSave(this));
        features.add(new Protection.AntiStasis(this));
        features.add(new Protection.PvpToggle(this));
        features.add(new Protection.DamageMod(this));

        // bans
        features.add(new Bans.ItemBan(this));
        features.add(new Bans.NetheriteBan(this));
        features.add(new Bans.Explosives(this));
        features.add(new Bans.Draining(this));
        features.add(new Bans.TippedArrows(this));
        features.add(new Bans.EnchantBan(this));
        features.add(new Bans.PotionBan(this));
        features.add(new Bans.DisableVaults(this));
        features.add(new Bans.DimensionBan(this));

        // fighting
        features.add(new Fighting.ShieldTweaks(this));
        features.add(new Fighting.Cooldowns(this));
        features.add(new Fighting.KillSound(this));
        features.add(new Fighting.InvisQol(this));
        features.add(new Fighting.TotemEffects(this));

        // world & mechanics
        features.add(new Tweaks.BlockDecay(this));
        features.add(new Tweaks.NoFallingBlocks(this));
        features.add(new Tweaks.FireControl(this));
        features.add(new Tweaks.AppleDrops(this));
        features.add(new Tweaks.BlockMechanics(this));
        features.add(new Tweaks.AnvilFix(this));
        features.add(new Tweaks.UnbreakableAnvils(this));
        features.add(new Tweaks.MobDisabler(this));
        features.add(new Tweaks.ArmorStandArms(this));
        features.add(new Tweaks.HappyGhastSpeed(this));
        features.add(new Tweaks.InfiniteRestock(this));
        features.add(new Tweaks.DisableTrades(this));
        features.add(new Tweaks.BlockTradeCycling(this));
        features.add(new Tweaks.RenderDistance(this));
        features.add(new Tweaks.LocatorBar(this));
        features.add(new Tweaks.OnePlayerSleep(this));
        features.add(new Miners.TreeMiner(this));
        features.add(new Miners.VeinMiner(this));
        features.add(new AltarFeature(this));
        features.add(new RecipesFeature(this));
        features.add(new Admin.DeathDrops(this));

        // server administration
        features.add(new Admin.DeathBan(this));
        features.add(new Admin.ChatFilter(this));
        features.add(new Admin.NoChatReports(this));
        features.add(new Admin.BookLimit(this));
        features.add(new Admin.ModDetector(this));
        features.add(new Admin.AntiMinimap(this));
        features.add(new Admin.Maintenance(this));
        features.add(new Admin.AntiAlt(this));
        features.add(new Admin.AntiVpn(this));

        // commands
        features.add(new Essentials.Homes(this));
        features.add(new Essentials.Spawn(this));
        features.add(new Essentials.Back(this));
        features.add(new Essentials.Tpa(this));
        features.add(new Essentials.Rtp(this));
        features.add(new Essentials.Heal(this));
        features.add(new Essentials.Broadcast(this));
        features.add(new Essentials.Links(this));
        features.add(new Essentials.Msg(this));
        features.add(new Essentials.Sit(this));
        features.add(new SettingsFeature(this));

        applyConfig();
        getLogger().info("SMPKit enabled.");
    }

    @Override
    public void onDisable() {
        features.forEach(Feature::shutdown);
        if (data != null) data.save();
    }

    /** (Re)loads config.yml and starts / reloads / stops each feature accordingly. */
    public void applyConfig() {
        reloadConfig();
        messages.reload(getConfig());
        for (Feature feature : features) {
            feature.apply(getConfig().getConfigurationSection("features." + feature.key()));
        }
    }

    public List<Feature> features() { return features; }

    /** Flips a feature on/off, saves it to config.yml and applies it immediately. */
    public void toggleFeature(String key) {
        for (Feature feature : features) {
            if (!feature.key().equals(key)) continue;
            getConfig().set("features." + key + ".enabled", !feature.isRunning());
            saveConfig();
            feature.apply(getConfig().getConfigurationSection("features." + key));
            return;
        }
    }

    public Messages messages() { return messages; }
    public DataStore data() { return data; }
    public ItemLimitFeature itemLimits() { return itemLimits; }

    // ------------------------------------------------------------------ commands

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (name.equals("smpkit")) {
            return handleAdmin(sender, args);
        }
        if (name.equals("itemlimit")) {
            String[] shifted = new String[args.length + 1];
            shifted[0] = "limits";
            System.arraycopy(args, 0, shifted, 1, args.length);
            handleLimits(sender, shifted);
            return true;
        }
        for (Feature feature : features) {
            if (feature.commands().contains(name)) {
                if (!feature.isRunning()) {
                    messages.send(sender, "feature-disabled");
                    return true;
                }
                return feature.handleCommand(sender, name, args);
            }
        }
        return false;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (name.equals("smpkit")) {
            if (args.length == 1) return Feature.filter(List.of("reload", "limits"), args[0]);
            if (args.length == 2 && args[0].equalsIgnoreCase("limits")) return Feature.filter(List.of("reset"), args[1]);
            if (args.length == 3 && args[0].equalsIgnoreCase("limits") && args[1].equalsIgnoreCase("reset")) {
                return Feature.filter(itemLimits.limits().keySet().stream().map(Material::name).toList(), args[2]);
            }
            return List.of();
        }
        for (Feature feature : features) {
            if (feature.commands().contains(name)) return feature.tabComplete(sender, name, args);
        }
        return List.of();
    }

    private boolean handleAdmin(CommandSender sender, String[] args) {
        if (args.length == 0) {
            messages.send(sender, "usage-admin");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                applyConfig();
                messages.send(sender, "reloaded");
            }
            case "limits" -> handleLimits(sender, args);
            default -> messages.send(sender, "usage-admin");
        }
        return true;
    }

    private void handleLimits(CommandSender sender, String[] args) {
        if (!itemLimits.isRunning()) {
            messages.send(sender, "feature-disabled");
            return;
        }
        if (args.length >= 3 && args[1].equalsIgnoreCase("reset")) {
            Material material = Material.matchMaterial(args[2]);
            if (material == null || !itemLimits.limits().containsKey(material)) {
                messages.send(sender, "limits-unknown");
                return;
            }
            itemLimits.reset(material);
            messages.send(sender, "limits-reset", Placeholder.unparsed("item", Messages.pretty(material)));
            return;
        }
        sender.sendMessage(messages.prefixed("limits-header"));
        for (Map.Entry<Material, Integer> entry : itemLimits.limits().entrySet()) {
            sender.sendMessage(messages.raw("limits-line",
                    Placeholder.unparsed("item", Messages.pretty(entry.getKey())),
                    Placeholder.unparsed("crafted", String.valueOf(itemLimits.crafted(entry.getKey()))),
                    Placeholder.unparsed("limit", String.valueOf(entry.getValue()))));
        }
    }
}
