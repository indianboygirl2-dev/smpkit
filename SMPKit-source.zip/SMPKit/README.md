# SMPKit

An original all-in-one SMP toolkit for **Paper 1.21.11** (Java 21). Everything is a separate module you can switch
on/off in `config.yml` or in-game with **/settings** (paged GUI, with `/settings <keyword>` search).

## Build
```
mvn clean package
```
Jar: `target/SMPKit-1.0.0.jar` -> put it in `plugins/`.

## Settings GUI
`/settings` shows one icon per feature (green + glow = on, red = off). Click to toggle; the change is saved to
config.yml and applied instantly. `smpkit.settings.view` = look only, `smpkit.settings` = can change.

## Features (65+ toggles)
**Rules & crafting:** craft limits (anti-dupe) - custom recipes (shaped/shapeless/furnace + vanilla remover) - altars & rituals - join kit
**Combat:** combat tag - damage limiters (anchor/bed/crystal/TNT/weapon caps) - PvP damage modifier - cooldowns - shield tweaks (no raise delay, mace stuns shield) - totem effects - invis QoL - kill sound - PvP toggle - naked protection - AFK protection - void protection - anti stasis - immortal items - immortal death drops
**Bans:** item ban - netherite ban - explosives (TNT, minecarts, crystals, anchors, beds) - draining - tipped arrows - enchant ban/caps - potion ban - vaults - dimension ban - death ban (+ /revive)
**World & mechanics:** block decay - no falling blocks - fire control - apple drops - block mechanics - anvil "too expensive" fix - unbreakable anvils - mob disabler - armor stand arms - happy ghast speed - infinite restock - disable villager trades - block trade cycling - render distance - locator bar - one-player sleep - tree miner - vein miner
**Server admin:** chat filter + spam limiter - no chat reports - book size limit - mod detector - anti minimap - maintenance mode - anti alt - anti VPN
**Staff tools:** vanish - invsee/ecsee - freeze (+ `/freeze all`)
**Player commands:** /home /sethome /delhome /homes - /spawn /setspawn - /back - /tpa /tpahere /tpaccept /tpdeny - /rtp - /heal - /broadcast - /discord /store - /msg /reply - /sit - /pvp

## Not included (and why)
- Anti HP indicators, anti seed cracking, anti durability-pack: need packet rewriting (ProtocolLib-level work).
- Anti X-Ray: use Paper's built-in anti-xray in `paper-world-defaults.yml` (it's the same thing).
- Attribute swap fix / breach swapping, instant brewing, stackable potions, reopenable vaults, clumps, heavy core drop, custom terrain, glowing custom items, custom brewing/anvil recipes.
- NPCs, arena repair, better /ban and /mute, /nick and /skin, /rollback, /worldtp, /settickrate, offline invsee.

## Notes
- `invsee` / `ecsee` work on online players only.
- `anti-minimap` only affects mods that honour the codes (Xaero's does); a modified client can ignore it.
- `anti-vpn` calls ip-api.com (free tier, HTTP) and fails open if the lookup fails.
- `no-chat-reports` re-sends chat as unsigned system messages, which also hides it from chat plugins that cancel/replace chat after SMPKit.
- Cooldowns, the shield delay fix and the locator bar use runtime APIs/commands that changed in recent versions; check `/smpkit reload` output in console after first boot.
